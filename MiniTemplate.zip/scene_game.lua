local Tile = require "tile"
local Player = require "player"
--require "player_no_UI"

-- the SUIT Object itseld
GAME_UI = SUIT.new()

-- Options for UI from the SUIT library
MOVEMENT = {
  IS_TANK        = false,
  IS_TOPDOWN     = false,
  IS_PLATFORMER  = false,
  IS_TILE_BUTTON = false,
  IS_TILE_CLICK  = false,
  IS_CLICK       = true
}

OPTIONS = {
  IS_JUMP = false,
  IS_ACCEL = false,
  IS_FRICT = false,
  IS_SPEED = false
}

GRID = {}
SHOW_GRID = {}
GUESS_GRID = {}

GAME_SCALE_X = 1
GAME_SCALE_Y = 1

local mx = -1
local my = -1

local restart_btn = nil


local button = require "my_lib.button"
local scale = require "my_lib.scale"
local GUIM = require "my_lib.GUIM" 
local game_UI = nil

local full_idx 
local tank_idx 
local topdown_idx 
local platformer_idx 
local tile_button_idx 
local tile_click_idx 
local click_idx 

local move_region_idx



local back_idx 



local font_path_1 = "fonts//VT323-Regular.ttf"
local font_path_2 = "fonts//Kaph-Regular.ttf"
local font_path_3 = "font//comic_neue_bold_19.ttf"
local size_font = 15

local collider = require "my_lib.collider"
local angle = require "my_lib.angle_convert"
local collision_manager = collider:new()
local angle_convert = angle:new()
local time = 0 
local the_seconds = 0

local temp_widget = nil
local temp_target = nil
local temp_time = 0.5
local temp_refill = temp_time

local black = {r = 0, g = 0, b = 0, a = 1}
local white = {r = 1, g = 1, b = 1, a = 1}
local gray  = {r = 0.5, g = 0.5, b = 0.5, a = 1}

---------------------------------------------------------------------------------------------------------------
-- The Game Scene
---------------------------------------------------------------------------------------------------------------

local function clamp(value, lower, upper)
  return math.max(lower , math.min(value, upper))
end

local function distance_to(x1, y1, x2, y2)
  return math.sqrt((x2 - x1) ^ 2 + (y2 - y1) ^ 2)
end

local function lerp(a, b, pct)
  return a + (b - a) * pct
end

local function angle_to(x1, y1, x2, y2)
  return math.atan( y2 - y1, x2 - x1)
end

local function create_2D_array(width, height, filler)
  local array_2d = {}

  for y = 1, height do
    table.insert( array_2d, {})
    for x = 1, width do
      -- in the case the array is an array
      table.insert( array_2d[y], filler )
    end
  end

  return array_2d
end

local function create_1D_array(length, filler)
  local array_1d = {}

  
  for x = 1, length do
    -- in the case the array is an array
    table.insert( array_1d, filler )
  end


  return array_1d
end

local function display2d(array2d)
  local s = ""
  for y = 1, #array2d do
      s = s.."["
      for x = 1, #array2d[y] do
        s = s.." "..tostring(array2d[y][x])..", "
        --s = s.." "..colors[array2d[y][x]]..", "
      end
      s = s.."]".."\n"
  end
  print(s)
end

local function display1d(array1d)
  local s = "["
  for i= 1, #array1d do
    s = s.." "..tostring(array1d[i])..", "
    --s = s.." "..colors[array2d[y][x]]..", "
  end
  s = s.."]".."\n"

  print(s)
end

local function remove_choice(tbl, value)
    for i = #tbl, 1, -1 do
        if tbl[i] == value then
            table.remove(tbl, i)
            return
        end
    end
end

local function load_map(array_2d)
  for y = 1,#array_2d do
    for x = 1,#array_2d[y] do
      if array_2d[y][x] == 1  then
        
        local positions = {x = x * TILESIZE - TILESIZE, y = y * TILESIZE - TILESIZE}
        local dimesions = {w = TILESIZE, h = TILESIZE}
        local t = Tile(
          positions,
          dimesions,
          0,
          nil,
          3 * TILESIZE,
          8 * TILESIZE,
          true,
          TILES
          )
        
        --table.insert(TILES,t)
      --[[
      --used to load player 
      elseif array_2d[y][x] == 9 then
        local positions = {x = x * TILESIZE - TILESIZE, y = y * TILESIZE - TILESIZE}
        local dimesions = {w = TILESIZE, h = TILESIZE}
        local t = Player(
          positions,
          dimesions,
          10,
          PLAYER_IMAGE_PATH,
          0,
          0,
          true,
          PROTAG
        )
        --table.insert(P,t)
        array_2d[y][x] = 0
        ]]
      end
      
    end
  end
end

local function set_player_to_random_tile(array_2d, floor_tile)
  local viable_tiles = {}
 
  for y = 1,#array_2d do
    for x = 1,#array_2d[y] do
      --print(array_2d[y][x])
      if array_2d[y][x] == floor_tile  then
        --print("yep")
        table.insert(viable_tiles, VECTOR2(x * TILESIZE - TILESIZE, y * TILESIZE - TILESIZE))
      end
    end
  end
  
  local positions = viable_tiles[math.floor(#viable_tiles * love.math.random())] 
  --print(positions)
  local dimesions = {w = TILESIZE, h = TILESIZE}
  if #PROTAG < 1 then
    --P[1].map_reference = MAP_TILES
    --adds itseld to to PROTAG table
    Player(
          positions,
          dimesions,
          10,
          nil,
          0,
          0,
          true,
          PROTAG
        )
    
  else

    LUME.clear(PROTAG)
    Player(
          positions,
          dimesions,
          10,
          nil,
          0,
          0,
          true,
          PROTAG
        )
    
  end

end

local function setup_UI()
  SCREEN_WIDTH = love.graphics.getWidth()
  SCREEN_HEIGHT = love.graphics.getHeight()
  game_UI = GUIM:new()
  game_UI.show_index = false
  game_UI.show_widget = true
  local k = ""
  full_idx = game_UI:add_area(
            {
              area = {
              x1 = 0,
              y1 = 0,
              x2 = SCREEN_WIDTH,
              y2 = SCREEN_HEIGHT
              },
              fill = "",
              mode = "",
              ext_anchor = "",
              int_anchor = "N",
              parent_idx = nil,
              rgb = black
              --[[
              rgb = {
                r = r,
                g = g,
                b = b,
                a = a
              }
              ]]
            
            }
  )

  local back_region_idx = game_UI:add_area(
            {
              --width_pct = 20,
              --height_pct = 100,
              min_pct = 15,
              fill = "",
              mode = "",
              ext_anchor = "",
              int_anchor = "NW",
              parent_idx = full_idx,
              rgb = black
              --[[
              rgb = {
                r = r,
                g = g,
                b = b,
                a = a
              }
              ]]
            
            }
  )

  back_idx = game_UI:add_area(
      {
              width_pct = 80,
              height_pct = 80,
              --min_pct = 90,
              fill = "",
              mode = "",
              ext_anchor = "",
              int_anchor = "SE",
              parent_idx = back_region_idx,
              rgb = black,
              widget = button:new(
                {
                --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
                --text = tostring(i),
                text = "<",
                text_anchor = "C",
                mode = "line",
                text_rgb = black,
                --img = "armilk88-2049037086209040422-01.jpg",
                --img_anchor = "NW",
                --font_style = 35,
                --font_path = "fonts/VT323-Regular.ttf",
                --word_wrap = true

                font_size = size_font,
                font_path = font_path_2,
                draw_polygon = true,
                draw_image = true,
                rgb = white,
                rx = 5,
                ry = 5,
                segments = 10,
                line_width = 3
                


                }
              )
            
      }
  )



  move_region_idx = game_UI:add_area(
            {
              width_pct = 15,
              height_pct = 100,
              --min_pct = 90,
              fill = "",
              mode = "",
              ext_anchor = "",
              int_anchor = "NE",
              parent_idx = full_idx,
              rgb = black,
              widget = button:new(
                {
                --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
                --text = tostring(i),
                --text = "Tank",
                --text_rgb = black,
                --text_anchor = "C",
                mode = "line",
                --img = "armilk88-2049037086209040422-01.jpg",
                --img_anchor = "NW",
                --font_style = 35,
                --font_path = "fonts/VT323-Regular.ttf",
                --word_wrap = true

                font_size = size_font,
                font_path = font_path_2,
                --draw_polygon = true,
                --draw_image = true,
                --rgb = white,
                rx = 5,
                ry = 5,
                segments = 10,
                line_width = 3
                


                }
              )
              --[[
              rgb = {
                r = r,
                g = g,
                b = b,
                a = a
              }
              ]]
            
            }
  )

  tank_idx = game_UI:add_area(
      {
              width_pct = 100,
              height_pct = 16.666,
              --min_pct = 85,
              fill = "",
              mode = "",
              ext_anchor = "",
              int_anchor = "N",
              parent_idx = move_region_idx,
              rgb = black,
              widget = button:new(
                {
                --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
                --text = tostring(i),
                text = "Tank",
                text_rgb = black,
                text_anchor = "C",
                mode = "line",
                --img = "armilk88-2049037086209040422-01.jpg",
                --img_anchor = "NW",
                --font_style = 35,
                --font_path = "fonts/VT323-Regular.ttf",
                --word_wrap = true

                font_size = size_font,
                font_path = font_path_2,
                draw_polygon = true,
                draw_image = true,
                rgb = white,
                rx = 5,
                ry = 5,
                segments = 10,
                line_width = 3
                


                }
              )
            
      }
  )

  topdown_idx = game_UI:add_area(
      {
              width_pct = 100,
              height_pct = 100,
              --min_pct = 90,
              fill = "",
              mode = "",
              ext_anchor = "SW",
              int_anchor = "",
              parent_idx = tank_idx,
              rgb = black,
              widget = button:new(
                {
                --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
                --text = tostring(i),
                text = "Top Down",
                text_rgb = black,
                text_anchor = "C",
                mode = "line",
                --img = "armilk88-2049037086209040422-01.jpg",
                --img_anchor = "NW",
                --font_style = 35,
                --font_path = "fonts/VT323-Regular.ttf",
                --word_wrap = true

                font_size = size_font,
                font_path = font_path_2,
                draw_polygon = true,
                draw_image = true,
                rgb = white,
                rx = 5,
                ry = 5,
                segments = 10,
                line_width = 3
                


                }
              )
            
      }
  )

  platformer_idx = game_UI:add_area(
      {
              width_pct = 100,
              height_pct = 100,
              --min_pct = 90,
              fill = "",
              mode = "",
              ext_anchor = "SW",
              int_anchor = "",
              parent_idx = topdown_idx,
              rgb = black,
              widget = button:new(
                {
                --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
                --text = tostring(i),
                text = "Platformer",
                text_rgb = black,
                text_anchor = "C",
                mode = "line",
                --img = "armilk88-2049037086209040422-01.jpg",
                --img_anchor = "NW",
                --font_style = 35,
                --font_path = "fonts/VT323-Regular.ttf",
                --word_wrap = true

                font_size = size_font,
                font_path = font_path_2,
                draw_polygon = true,
                draw_image = true,
                rgb = white,
                rx = 5,
                ry = 5,
                segments = 10,
                line_width = 3
                


                }
              )
            
      }
  )

  tile_button_idx = game_UI:add_area(
      {
              width_pct = 100,
              height_pct = 100,
              --min_pct = 90,
              fill = "",
              mode = "",
              ext_anchor = "SW",
              int_anchor = "",
              parent_idx = platformer_idx,
              rgb = black,
              widget = button:new(
                {
                --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
                --text = tostring(i),
                text = "Tile Button",
                text_rgb = black,
                text_anchor = "C",
                mode = "line",
                --img = "armilk88-2049037086209040422-01.jpg",
                --img_anchor = "NW",
                --font_style = 35,
                --font_path = "fonts/VT323-Regular.ttf",
                --word_wrap = true

                font_size = size_font,
                font_path = font_path_2,
                draw_polygon = true,
                draw_image = true,
                rgb = white,
                rx = 5,
                ry = 5,
                segments = 10,
                line_width = 3
                


                }
              )
            
      }
  )

  tile_click_idx = game_UI:add_area(
      {
              width_pct = 100,
              height_pct = 100,
              --min_pct = 90,
              fill = "",
              mode = "",
              ext_anchor = "SW",
              int_anchor = "",
              parent_idx = tile_button_idx,
              rgb = black,
              widget = button:new(
                {
                --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
                --text = tostring(i),
                text = "Tile Click",
                text_rgb = black,
                text_anchor = "C",
                mode = "line",
                --img = "armilk88-2049037086209040422-01.jpg",
                --img_anchor = "NW",
                --font_style = 35,
                --font_path = "fonts/VT323-Regular.ttf",
                --word_wrap = true

                font_size = size_font,
                font_path = font_path_2,
                draw_polygon = true,
                draw_image = true,
                rgb = white,
                rx = 5,
                ry = 5,
                segments = 10,
                line_width = 3
                


                }
              )
            
      }
  )

  click_idx = game_UI:add_area(
      {
              width_pct = 100,
              height_pct = 100,
              --min_pct = 90,
              fill = "",
              mode = "",
              ext_anchor = "SW",
              int_anchor = "",
              parent_idx = tile_click_idx,
              rgb = black,
              widget = button:new(
                {
                --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
                --text = tostring(i),
                text = "Click",
                text_rgb = black,
                text_anchor = "C",
                mode = "line",
                --img = "armilk88-2049037086209040422-01.jpg",
                --img_anchor = "NW",
                --font_style = 35,
                --font_path = "fonts/VT323-Regular.ttf",
                --word_wrap = true

                font_size = size_font,
                font_path = font_path_2,
                draw_polygon = true,
                draw_image = true,
                rgb = white,
                rx = 5,
                ry = 5,
                segments = 10,
                line_width = 3
                


                }
              )
            
      }
  )

 

      
  
  
  game_UI:draw()

end

local function setup_player()
  if #PROTAG == 0 then

    set_player_to_random_tile(LEVEL, 0)
    CAM:lookAt((LEVEL_WIDTH*CAMERA_ZOOM)/2,(LEVEL_HEIGHT*CAMERA_ZOOM)/2)

  end
  PROTAG[1].move_speed = SPEED_DATA.value     
  PROTAG[1].move_speed = SPEED_DATA.value     
  PROTAG[1].friction = FRICTION_DATA.value  
  PROTAG[1].acceleration = ACCEL_DATA.value     
  PROTAG[1].jump_height = JUMP_HGHT_DATA.value 
  PROTAG[1].jump_time_to_peak = JUMP_PEAK_DATA.value 
  PROTAG[1].jump_time_to_descent = JUMP_DESC_DATA.value 

  local jv = ((2.0 * PROTAG[1].jump_height)/ PROTAG[1].jump_time_to_peak) * -1.0
  local jg = ((-2.0 * PROTAG[1].jump_height)/ (PROTAG[1].jump_time_to_peak*PROTAG[1].jump_time_to_peak)) * -1.0
  local fg = ((-2.0 * PROTAG[1].jump_height)/ (PROTAG[1].jump_time_to_descent*PROTAG[1].jump_time_to_descent)) * -1.0

  PROTAG[1].jump_velocity = jv
  PROTAG[1].jump_gravity =  jg
  PROTAG[1].fall_gravity = fg

end

local function highlight_widget(widget_idx)
  
  local button = game_UI.widgets[widget_idx]
  if button ~= "" then 

    if button:_is_hovering_over(mx, my) then
      --print(("Over %d"):format(widget_idx))
      button.text_rgb = black
      button.rgb = white
      button.mode = "fill" 

    else

      button.text_rgb = black
      button.rgb = white
      button.mode = "line"

    end

  end

  

end

local function highlight_selected()
  


 
  if MOVEMENT.IS_TANK then 
    game_UI.widgets[tank_idx].text_rgb = black
    game_UI.widgets[tank_idx].rgb = white
    game_UI.widgets[tank_idx].mode = "fill"
  end

  if MOVEMENT.IS_TOPDOWN then 
    game_UI.widgets[topdown_idx].text_rgb = black
    game_UI.widgets[topdown_idx].rgb = white
    game_UI.widgets[topdown_idx].mode = "fill"
  end

  if MOVEMENT.IS_PLATFORMER then 
    game_UI.widgets[platformer_idx].text_rgb = black
    game_UI.widgets[platformer_idx].rgb = white
    game_UI.widgets[platformer_idx].mode = "fill"
  end

  if MOVEMENT.IS_TILE_BUTTON then 
    game_UI.widgets[tile_button_idx].text_rgb = black
    game_UI.widgets[tile_button_idx].rgb = white
    game_UI.widgets[tile_button_idx].mode = "fill"
  end

  if MOVEMENT.IS_TILE_CLICK then 
    game_UI.widgets[tile_click_idx].text_rgb = black
    game_UI.widgets[tile_click_idx].rgb = white
    game_UI.widgets[tile_click_idx].mode = "fill"
  end

  if MOVEMENT.IS_CLICK then 
    game_UI.widgets[click_idx].text_rgb = black
    game_UI.widgets[click_idx].rgb = white
    game_UI.widgets[click_idx].mode = "fill"
  end


  

end

local function select_movement()
  
  if game_UI.widgets[move_region_idx]:_is_hovering_over(mx, my) then
    MOVEMENT.IS_TANK        = game_UI.widgets[tank_idx]:_is_hovering_over(mx, my)
    MOVEMENT.IS_TOPDOWN     = game_UI.widgets[topdown_idx]:_is_hovering_over(mx, my)
    MOVEMENT.IS_PLATFORMER  = game_UI.widgets[platformer_idx]:_is_hovering_over(mx, my)
    MOVEMENT.IS_TILE_BUTTON = game_UI.widgets[tile_button_idx]:_is_hovering_over(mx, my)
    MOVEMENT.IS_TILE_CLICK  = game_UI.widgets[tile_click_idx] :_is_hovering_over(mx, my)
    MOVEMENT.IS_CLICK       = game_UI.widgets[click_idx]:_is_hovering_over(mx, my)
  end
end

function GAME_SCENE:enter()
  --upon entering the state
  --create_board()



  
  setup_UI()
  setup_player()
  
end

function GAME_SCENE:init()
  -- SUIT.theme.color.normal.fg = {255,255,255}
  -- SUIT.theme.color.hovered = {bg = {200,230,255}, fg = {0,0,0}}
  -- init_UI()
  
  --basic_quad =  love.graphics.newQuad(0,1,16,16,tileset)
  --SPRITEBATCH = love.graphics.newSpriteBatch(love.graphics.newImage(TILESET_PATH))

  setup_UI()
  load_map(MAP_TILES)
  -- adds the player to the PROTAG array
  

  setup_player()
  --GAM:setWorld(0,0,WORLD_LEVEL_WIDTH,WORLD_LEVEL_HEIGHT)
end


function GAME_SCENE:update(dt)
  
  
  mx, my = love.mouse.getPosition()
  local widget_indexes  ={
    tank_idx, 
    topdown_idx,
    platformer_idx,
    tile_button_idx,
    tile_click_idx, 
    click_idx,
    back_idx
  }

  
  for i = 1, #widget_indexes do
    highlight_widget(widget_indexes[i])
  end

  highlight_selected()

  for k, v in pairs(PROJECTILES) do
    v:update(dt)
  end
  --[[

  highlight_widget(tank_idx)
  highlight_widget(topdown_idx)
  highlight_widget(platformer_idx)
  highlight_widget(tile_button_idx)
  highlight_widget(tile_click_idx) 
  highlight_widget(click_idx)

  ]]

  if #PROTAG > 0 then
    --local bx,by = CAM:cameraCoords(SCREEN_WIDTH/4,SCREEN_HEIGHT/4)
    --local bw,bh = CAM:cameraCoords(LEVEL_WIDTH,LEVEL_HEIGHT) 
    --CAM.x = LUME.lamp(CAM.x,bx,bw)
    --CAM.y = LUME.clamp(CAM.y,by,bh)
    
    --GAME_SCENE:update_UI()
    --GAME_SCENE:draw_UI(GAME_UI)
    

    PROTAG[1]:update(dt)


    

  end

end

function GAME_SCENE:draw()
  
  
  CAM:attach()
  --GAM:draw(function ()
    
    --

    --love.graphics.circle("line",CAM.x,CAM.y,6)
    
    if #TILES > 0 then
      --SPRITEBATCH:clear()
      local rendered_tiles = 0
      --local cx,cy,cw,ch = GAM:getVisible()
      local cx, cy = -TILESIZE, -TILESIZE
      local cw, ch = SCREEN_WIDTH + TILESIZE, SCREEN_HEIGHT + TILESIZE 

      --local cx, cy = CAM:worldCoords(0, 0)
      --local cw, ch = CAM:worldCoords(SCREEN_WIDTH, SCREEN_HEIGHT)
      
      --cx, cy = PROTAG[1]:world_to_array2d(cx, cy)
      --cw, ch = TILES[1]:world_to_array2d(cw, ch)
      --print(cx, cy, cw, ch)

      for i, ent in ipairs(TILES) do
        local tx, ty = CAM:cameraCoords(ent.position.x + ent.dimension.x/2, ent.position.y + ent.dimension.y/2)
        
        --local tx, ty = ent.position.x, ent.position.y 
        --tx, ty = ent:world_to_array2d(tx, ty)
        if i == 1 then
          --print(tx, ty)
        end

        --culling tiles
        if ent.collider:point_rectangle(
                                              tx, ty,  
                                              cx, cy, 
                                              cw, ch) then

          rendered_tiles = rendered_tiles + 1
          ent:display("fill")
          --SPRITEBATCH:add(ent.quad, math.floor(ent.position.x ), math.floor(ent.position.y))
        end
      end
      --print(rendered_tiles)
      -- Finally, draw the sprite batch to the screen.
      --love.graphics.draw(SPRITEBATCH)
      --draw_UI(GAME_UI)
    end

    if #PROTAG > 0 then
      
      PROTAG[1]:draw()

    end

    for _, v in ipairs(PROJECTILES) do
      v:display("line")
    end

    
  --end
    
  CAM:detach()
  game_UI:draw()
  
  --debug
  --if VISIBLE.IS_DEBUG then
    --debug_statements()
  --end

  
  
end




function GAME_SCENE:mousepressed(x, y, button, istouch)
  -- for tile based input
  if #PROTAG > 0 then
    if #PROTAG[1].tile_path > 0 then 
      PROTAG[1].canceled_path = true
    end
  end
  select_movement()
  if game_UI.widgets[back_idx]:_is_hovering_over(mx, my) then
    GAMESTATE.switch(MENU_SCENE)
  end
end

function GAME_SCENE:keypressed(key)
  if key == "space" then
    GAMESTATE.switch(PAUSE_SCENE)
  elseif key == "p" then
    --display(LEVEL)
    print("")
  elseif key == "r" then
    
    -- restart
    set_player_to_random_tile(LEVEL, 0)
    if #PROTAG  > 0 then
      PROTAG[1]:restart()
    end
  
  --[[
  elseif key == "j" then
    local p = {
      PROTAG[1].move_speed,       
      PROTAG[1].friction,            
      PROTAG[1].acceleration,        
      PROTAG[1].jump_height,        
      PROTAG[1].jump_time_to_peak,   
      PROTAG[1].jump_time_to_descent
    }

    for i = 1, #p do
      print(p[i])
    end

    print("")
    ]]
  end
end

function GAME_SCENE:wheelmoved(x, y)
  if #PROTAG > 0 then
    --if P[1].button_tile_input or P[1].mouse_tile_input then 
      local temp = {x = CAMERA_ZOOM}
      local max_zoom = 10
      local min_zoom = 1
      local zoom_dir = 0
      local zoom_speed = 20
      if y > 0 then
        --up
          CAMERA_ZOOM = CAMERA_ZOOM + zoom_speed * PROTAG[1].delta_time
        
      elseif y < 0 then
        --down
          CAMERA_ZOOM = CAMERA_ZOOM - zoom_speed * PROTAG[1].delta_time
          
      end
      --FLUX.to(, .5, { x = CAMERA_ZOOM }):ease("circout"):delay(1)
      CAMERA_ZOOM = LUME.clamp(CAMERA_ZOOM, min_zoom, max_zoom)
      
      --if CAMERA_ZOOM <= max_zoom and CAMERA_ZOOM >= min_zoom then
        --FLUX.to(temp, 0.2, {x = CAMERA_ZOOM})
      --end
      CAM:zoomTo(temp.x)
      --GAM:setScale(temp.x)
    --end
  end
end

function GAME_SCENE:resize(w, h)
  game_UI.areas[1] = {x1 = 0, y1 = 0, x2 = SCREEN_WIDTH, y2 = SCREEN_HEIGHT}
  
  --[[
  -- attempts to rescale the font 
  local scale = clamp(
                      math.floor(math.min(SCREEN_WIDTH, SCREEN_HEIGHT)/math.min(VIRTUAL_WIDTH, VIRTUAL_HEIGHT)),
                      1, 100)
  for i = 1, #game_UI.widgets do
    local widget = game_UI.widgets[i]
    if widget ~= {} and widget.name == "button" then
      if widget.font_size ~= -1 then
        widget.font_size = widget.font_size * scale
        widget.font_type = love.graphics.newFont(widget.font_path, widget.font_size) 
        --widget.font = love.graphics.setNewFont(widget.font)

      end
    end
  end
  ]]
  game_UI:update_areas()
  game_UI:draw()

  --[[
  draw_widget(true, cell_start, cell_start + 80)
  draw_widget(true, choice_start, choice_start + 9)
  draw_widget(true, restart_idx)
  draw_widget(true, menu_idx)
  draw_widget(true, timer_idx)
  ]]
end

