require "entity_2D"
require "bullet"

local Player = ENTITY:extend()



function Player:new(position_table,dimension_table,hp,image_path,quad_x,quad_y,in_world,group_table)
  Player.super.new(self,
    position_table,
    dimension_table,
    hp,
    image_path,
    quad_x,
    quad_y,
    in_world,
    group_table)
  
  --size of single frame in spritesheer
  
  --self.frame_size = 24
  self.max_speed = 200
  self.rotation_speed = 200
  self.button_tile_input = true
  self.mouse_tile_input = false
  --mouse offeset
  self.mx = 0
  self.my = 0
  self.vy = 0

  self.walkable_tile = 0
  self.unreachable_tile = 1
  self.mouse_vector = VECTOR2(self.mx, self.my)


  
  self.current_ammo = 25
  self.seconds_refill = 0.8
  self.seconds_fire = 0.3

  --size of cell in the spritesheet
  self.frame_size = TILESIZE

  
end

function Player:fire_bullet()
  
  -- with hump timer
  -- without hump's Timer
  -- updates angle
  local angle = LUME.angle(
                        self.position.x + (self.dimension.x/2),
                        self.position.y + (self.dimension.y/2), 
                        self.mouse_vector.x, 
                        self.mouse_vector.y
                      )

  self.angle = self.angle_convert:radians_to_degrees(angle)

  self.sin = math.sin(angle)
  self.cos = math.cos(angle)

  

  --adding randoness to the bullet launch
  --angle = self.angle_convert:degrees_to_radians(self.angle + love.math.random(-15, 15))
  local a_sin = math.sin(angle)
  local a_cos = math.cos(angle)


  --print("yep")
  local dist = math.max(WORLD_LEVEL_HEIGHT, WORLD_LEVEL_WIDTH) * 5
  local x_target = self.position.x + self.dimension.x/2 + dist * a_cos
  local y_target = self.position.y + self.dimension.y/2 + dist * a_sin
  local target_position = VECTOR2(x_target, y_target)
  local position = {x = self.line.x2, y = self.line.y2}

  local dimesions = {w = 5, h = 5}

  
  local t = Bullet(
    position,
    dimesions,
    10,
    nil,
    0,
    0,
    false,
    PROJECTILES
  )


  
  
  
  --bullet owner ship
  t.owner = "player"
  --adding velocity so bullets have a constant speed as the player moves
  t.move_speed = self.move_speed + t.move_speed
  t.target_position = target_position
  

  --meant to help the hitbox keep up with the sudden velocity change
  local last_pos_x = self.position.x
  local last_pos_y = self.position.y

  --knockback, works when friction is less than 1
  --self.velocity.x = LUME.lerp(self.velocity.x, self.velocity.x + -t.move_speed * a_cos, self.acceleration/2)
  --self.velocity.y = LUME.lerp(self.velocity.y, self.velocity.y + -t.move_speed * a_sin, self.acceleration/2)

  --self.seconds_fire = 0.20 --+ love.math.random(0.05, 0.08) 
  
  local pos_x_change = self.position.x - last_pos_x
  local pos_y_change = self.position.y - last_pos_y
  
  --[[
  for i = 1, #self.hitbox, 2  do
    local x_ind = i
    local y_ind = i + 1
    --keeping the hitbox aligned with the position
    self.hitbox[x_ind] = self.hitbox[x_ind] + pos_x_change
    self.hitbox[y_ind] = self.hitbox[y_ind] + pos_y_change
  end
  ]]--
    
  --end
  
end

function Player:update(dt)
  --hump camera
  local mx,my = CAM:worldCoords(love.mouse.getPosition())
  
  --kikito's gamera
  --local mx, my = GAM:toWorld(love.mouse.getPosition())
  --gam:setPosition(self.x + self.w/2,self.y + self.h/2)
  CAM:lookAt(self.position.x + self.dimension.x/2,self.position.y + self.dimension.y/2)
  
  local mx, my = love.mouse.getPosition()
  self.mx, self.my =  CAM:worldCoords(love.mouse.getPosition())
  self.mouse_vector.x = self.mx 
  self.mouse_vector.y = self.my
  

  self.delta_time = dt

  local LMB = love.mouse.isDown(1)
  local RMB = love.mouse.isDown(2)
  local up = love.keyboard.isDown('up','w')
  local down = love.keyboard.isDown('down','s')
  local right = love.keyboard.isDown('right','d')
  local left = love.keyboard.isDown('left','a')
  local up_right = up and right
  local up_left = up and left
  local down_right = down and right
  local down_left = down and left

  
  if RMB then
    -- uses original code 
    -- uses the end of the line as the place 
    -- where the bullet initializes angle 
    --self:fire_bullets(dt)

    
    self.seconds_fire = self.seconds_fire - self.delta_time
    if self.seconds_fire <= 0 and self.current_ammo > 0 then
      --print("fired")
      self.current_ammo = self.current_ammo - 1
      self.seconds_fire = 0.1
      self:fire_bullet()
      --print(("secondes to fire %f"):format(self.seconds_fire))
    end
  

    
  else
    self.seconds_refill = self.seconds_refill - self.delta_time
    if self.seconds_refill <= 0 and self.current_ammo ~= self.total_ammo then
      --print("fired")
      self.current_ammo = LUME.clamp(self.current_ammo + 1, 0, 25)
      self.seconds_refill = 0.25
      
    end
  end


  --self:update_line_angle(dt)

  --current movement options
  
  --[[
  MOVEMENT = {
  IS_TANK        = false,
  IS_TOPDOWN     = false,
  IS_PLATFORMER  = false,
  IS_TILE_BUTTON = false,
  IS_TILE_CLICK  = false,
  IS_CLICK       = true
  }
  ]]
    
  
  if MOVEMENT.IS_TANK then
    self:tank_movement(dt)
  end
  if MOVEMENT.IS_TOPDOWN then
    self:topdown_2d_movement(dt)
  end
  if MOVEMENT.IS_PLATFORMER then
    self:platformer_2d_movement(dt)
  end
  if MOVEMENT.IS_TILE_BUTTON then
    self:tile_button_movement(self.delta_time, self.walkable_tile, self.unreachable_tile)
  
  end
  if MOVEMENT.IS_TILE_CLICK then
    self:follow_target_tile(self.delta_time, self.walkable_tile, self.mouse_vector)
  end
  if MOVEMENT.IS_CLICK then
    if LMB then
      --updates angle and position
      self:follow_target(dt, self.mouse_vector, true)
    else
      self.velocity = VECTOR2.zero
    end
  end
  --self:topdown_2d_movement(dt)
  --self:platformer_2d_movement(dt)
  --self:tile_button_movement(self.delta_time, self.walkable_tile, self.unreachable_tile)
  --self:follow_target_tile(self.delta_time, self.walkable_tile, self.mouse_vector)
    --self:relative_angle_movement(dt)

  

  


  
  --print(self.delta_time)
  --updates line angle: all below are in the entity_2D file
  self:update_line_angle()
  self:update_hitbox_position()

end

function Player:draw()
  
  
  
  
    if MOVEMENT.IS_TILE_CLICK then
      local boxx, boxy = self:world_to_array2d(self.mx, self.my) 
      local boxx, boxy = self:array2d_to_world(boxx, boxy)
      
      love.graphics.rectangle(
        "line",
        boxx,
        boxy,
        TILESIZE,
        TILESIZE
      )
    end
    --the player's hitbox
    love.graphics.polygon("line", self.hitbox)
    -- the line angle of the player
    if MOVEMENT.IS_CLICK or MOVEMENT.IS_TANK then
      self:draw_line()
    end

  

end


return Player
