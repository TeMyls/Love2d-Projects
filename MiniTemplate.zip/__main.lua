
local SCREEN_WIDTH = 800
local SCREEN_HEIGHT = 600

local boids = {}
local NUM_BOIDS = 100

function love.load()
    love.window.setMode(SCREEN_WIDTH, SCREEN_HEIGHT)

    for i = 1, NUM_BOIDS do
        table.insert(boids, {
            x = math.random() * SCREEN_WIDTH,
            y = math.random() * SCREEN_HEIGHT,
            angle = math.random() * 360,
            speed = 60
        })
    end
end

function love.update(dt)
    for i, v in ipairs(boids) do
        local to_vector = {x = 0, y = 0}
        local from_vector = {x = 0, y = 0}
        local with_vector = {x = 0, y = 0}

        local to_count = 0
        local with_count = 0

        local velocity = {
            x = v.speed * math.cos(math.rad(v.angle)),
            y = v.speed * math.sin(math.rad(v.angle))
        }

        for j, w in ipairs(boids) do
            if i ~= j then
                local dx = w.x - v.x
                local dy = w.y - v.y
                local dist = math.sqrt(dx*dx + dy*dy)

                if dist < 75 then
                    -- cohesion
                    to_vector.x = to_vector.x + w.x
                    to_vector.y = to_vector.y + w.y
                    to_count = to_count + 1

                    -- alignment
                    local wvx = w.speed * math.cos(math.rad(w.angle))
                    local wvy = w.speed * math.sin(math.rad(w.angle))

                    with_vector.x = with_vector.x + wvx
                    with_vector.y = with_vector.y + wvy
                    with_count = with_count + 1
                end

                if dist < 25 then
                    -- separation (push away)
                    from_vector.x = from_vector.x + (v.x - w.x)
                    from_vector.y = from_vector.y + (v.y - w.y)
                end
            end
        end

        -- finalize cohesion
        if to_count > 0 then
            to_vector.x = (to_vector.x / to_count) - v.x
            to_vector.y = (to_vector.y / to_count) - v.y
        end

        -- finalize alignment
        if with_count > 0 then
            with_vector.x = (with_vector.x / with_count) - velocity.x
            with_vector.y = (with_vector.y / with_count) - velocity.y
        end

        -- weights
        local cohesion_weight = 0.001
        local separation_weight = 0.05
        local alignment_weight = 0.05

        velocity.x = velocity.x
            + to_vector.x * cohesion_weight
            + from_vector.x * separation_weight
            + with_vector.x * alignment_weight

        velocity.y = velocity.y
            + to_vector.y * cohesion_weight
            + from_vector.y * separation_weight
            + with_vector.y * alignment_weight

        -- update angle
        v.angle = math.deg(math.atan(velocity.y, velocity.x))

        -- move (wrap around)
        v.x = (v.x + velocity.x * dt) % SCREEN_WIDTH
        v.y = (v.y + velocity.y * dt) % SCREEN_HEIGHT
    end
end

function love.draw()
    for _, v in ipairs(boids) do
        love.graphics.setColor(1, 1, 1)
        love.graphics.circle("fill", v.x, v.y, 3)

        -- direction line
        love.graphics.setColor(1, 1, 0)
        love.graphics.line(
            v.x,
            v.y,
            v.x + math.cos(math.rad(v.angle)) * 10,
            v.y + math.sin(math.rad(v.angle)) * 10
        )
    end
end
