---------------------------------------------------------------------------------------------------------------
-- The Pause Scene
---------------------------------------------------------------------------------------------------------------

DIFFICULTY = {
  _easy = true,
  _medium = false,
  _hard = false,
  _custom = false
}


TOTAL_GIVEN = 39
TOTAL_CELLS = 81


local button = require "my_lib.button"
local scale = require "my_lib.scale"
local GUIM = require "my_lib.GUIM" 
local options_UI = nil

local r, g, b, a = love.math.colorFromBytes(0, 0, 0, 1)--(172, 170, 189)

local font_path_1 = "fonts//VT323-Regular.ttf"
local font_path_2 = "fonts//Kaph-Regular.ttf"
local font_path_3 = "font//comic_neue_bold_19.ttf"

local full_region = nil
local main_region = nil
local button_region = nil
local title_region = nil
local easy_idx = nil
local medium_idx = nil
local hard_idx = nil
local custom_idx = nil
local custom_scl = nil
local switch_region = nil
local cells_region = nil
local switch_idx = nil
local scale_progress = 5

local move_idx
local speed_idx
local accel_idx 
local friction_idx

local jump_idx
local jump_hght_idx 
local jump_peak_idx
local jump_desc_idx

local speed_scl_idx
local accel_scl_idx
local friction_scl_idx
local jump_scl_hght_idx 
local jump_scl_peak_idx
local jump_scl_desc_idx

SPEED_DATA      = {value = 150, min = 25, max = 300}
FRICTION_DATA   = {value = 1, min = 0.05, max = 1}
ACCEL_DATA      = {value = 1, min = 0.05, max = 1}
JUMP_HGHT_DATA  = {value = 48, min = TILESIZE, max = TILESIZE * LEVEL_HEIGHT}
JUMP_PEAK_DATA  = {value = 0.5, min = 0.1, max = 20}
JUMP_DESC_DATA  = {value = 0.8, min = 0.1, max = 20} 

local diff_mode = -1

local mx = -1
local my = -1

local black = {r = 0, g = 0, b = 0, a = 1}
local white = {r = 1, g = 1, b = 1, a = 1}
local gray  = {r = 0.5, g = 0.5, b = 0.5, a = 1}

local function clamp(value, upper, lower)
  return math.max(lower, math.min(value, upper))
end


local function setup_UI()

  options_UI = GUIM:new()
  options_UI.show_index = false
  options_UI.show_widget = false
  local k = ""
  full_region = options_UI:add_area(
            {
              area = {
              x1 = 0,
              y1 = 0,
              x2 = SCREEN_WIDTH,
              y2 = SCREEN_HEIGHT
              },
              fill = "",
              mode = "fill",
              ext_anchor = "",
              int_anchor = "N",
              parent_idx = nil,
              rgb = black
              --[[
              rgb = {
                r = r,
                g = g,
                b = b,
                a = a
              }]]

            }
  )

  main_region = options_UI:add_area(
            {
              --width_pct = 90,
              --height_pct = 90,
              min_pct = 90,
              fill = "",
              mode = "",
              ext_anchor = "",
              int_anchor = "C",
              parent_idx = full_region,
              rgb = options_UI:get_random_rgb(),

            }
  )

  --[[
  button_region = options_UI:add_area(
            {
              --width_pct = 85,
              --height_pct = 90,
              min_pct = 95,
              fill = "",
              mode = "",
              ext_anchor = "",
              int_anchor = "N",
              parent_idx = main_region,
              rgb = options_UI:get_random_rgb()

            }
  )
  ]]

  switch_region = options_UI:add_area(
        {

          --width_pct = 100,
          --height_pct = 12.5,
          min_pct = 10,
          fill = "",
          mode = "",
          ext_anchor = "",
          int_anchor = "NW",
          parent_idx = full_region,
          rgb = white,
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          

        }
  )
  
  switch_idx = options_UI:add_area(
        {

          --width_pct = 100,
          --height_pct = 12.5,
          min_pct = 90,
          fill = "",
          mode = "",
          ext_anchor = "",
          int_anchor = "SE",
          parent_idx = switch_region,
          rgb = options_UI:get_random_rgb(),
          
          line_style = "smooth",

          --line_width = 10
          widget = button:new(
          
            {
              --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
              --text = tostring(i),

              text = "<",
              text_anchor = "C",
              --mode = "line",
              --img = "armilk88-2049037086209040422-01.jpg",
              --img_anchor = "NW",
              --font_style = 35,
              --font_path = "fonts/VT323-Regular.ttf",
              --word_wrap = true
              font_size = 35,
              font_path = font_path_2,
              draw_polygon = true,
              draw_image = true,
              rgb = white,
              rx = 5,
              ry = 5,
              segments = 10,
              line_width = 3

            }

          )

        }
  )

  title_region = options_UI:add_area(
        {

          width_pct = 100,
          height_pct = 10,
          --min_pct = 90,
          fill = "",
          mode = "",
          ext_anchor = "",
          int_anchor = "N",
          parent_idx = main_region,
          rgb = options_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          widget = button:new(
            {
              --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
              --text = tostring(i),

              text = "OPTIONS",
              text_anchor = "C",
              --mode = "line",
              --img = "armilk88-2049037086209040422-01.jpg",
              --img_anchor = "NW",
              --font_style = 35,
              --font_path = "fonts/VT323-Regular.ttf",
              --word_wrap = true
              font_size = 55,
              font_path = font_path_2,
              draw_polygon = true,
              draw_image = true,
              rgb = white,
              rx = 5,
              ry = 5,
              segments = 10,
              line_width = 3


              }
          )

        }
  )

  local button_region = options_UI:add_area(
        {

          width_pct = 100,
          height_pct = 90,
          --min_pct = 90,
          fill = "",
          mode = "",
          ext_anchor = "",
          int_anchor = "S",
          parent_idx = main_region,
          rgb = options_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          

        }
  )

  local left_region = options_UI:add_area(
        {

          width_pct = 50,
          height_pct = 100,
          --min_pct = 90,
          fill = "",
          mode = "",
          ext_anchor = "",
          int_anchor = "W",
          parent_idx = button_region,
          rgb = options_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          

        }
  )

  local right_region = options_UI:add_area(
        {

          width_pct = 50,
          height_pct = 100,
          --min_pct = 90,
          fill = "",
          mode = "",
          ext_anchor = "",
          int_anchor = "E",
          parent_idx = button_region,
          rgb = options_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          

        }
  )

  move_idx  = options_UI:add_area(
        {

          width_pct = 100,
          height_pct = 10,
          --min_pct = 90,
          fill = "",
          mode = "",
          ext_anchor = "",
          int_anchor = "NE",
          parent_idx = left_region,
          rgb = options_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          widget = button:new(
            {
              --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
              --text = tostring(i),
              
              text = "Movement",
              text_anchor = "C",
              mode = "",
              --img = "armilk88-2049037086209040422-01.jpg",
              --img_anchor = "NW",
              --font_style = 35,
              --font_path = "fonts/VT323-Regular.ttf",
              --word_wrap = true
              font_size = 25,
              font_path = font_path_2,
              draw_polygon = true,
              draw_image = true,
              rgb = options_UI:get_random_rgb(),
              rx = 5,
              ry = 5,
              segments = 10,
              line_width = 3


              }
          )

        }
  )

  speed_idx = options_UI:add_area(
        {

          width_pct = 100,
          height_pct = 100,
          --min_pct = 90,
          fill = "",
          mode = "",
          ext_anchor = "S",
          int_anchor = "",
          parent_idx = move_idx,
          rgb = options_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          widget = button:new(
            {
              --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
              --text = tostring(i),
              
              text = ("Speed: %d"):format(SPEED_DATA.value),
              text_anchor = "C",
              mode = "line",
              --img = "armilk88-2049037086209040422-01.jpg",
              --img_anchor = "NW",
              --font_style = 35,
              --font_path = "fonts/VT323-Regular.ttf",
              --word_wrap = true
              font_size = 25,
              font_path = font_path_2,
              draw_polygon = true,
              draw_image = true,
              rgb = options_UI:get_random_rgb(),
              rx = 5,
              ry = 5,
              segments = 10,
              line_width = 3


              }
          )

        }
  )
  
  speed_scl_idx = options_UI:add_area(
        {

          width_pct = 100,
          height_pct = 100,
          --min_pct = 90,
          fill = "",
          mode = "line",
          ext_anchor = "S",
          int_anchor = "",
          parent_idx = speed_idx,
          rgb = options_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          line_width = 3,
          widget = scale:new(
            {
              
              rgb = white,
              mode = "fill",

              rx = 5,
              ry = 5,
              segments = 5,

              --show_scroll_limit = true,
              progress = 0,
              has_scrollbar = true,
              --is_vertical = true,
              is_flipped = false,
              is_horizontal = true,
              --is_circular = true
              name = "tst_scl"
              

            }
          )

        }
  )

  accel_idx = options_UI:add_area(
        {

          width_pct = 100,
          height_pct = 100,
          --min_pct = 90,
          fill = "",
          --mode = "line",
          ext_anchor = "S",
          int_anchor = "",
          parent_idx = speed_scl_idx,
          rgb = options_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          widget = button:new(
            {
              --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
              --text = tostring(i),
              
              text = ("Speed: %d"):format(SPEED_DATA.value),
              text_anchor = "C",
              mode = "line",
              --img = "armilk88-2049037086209040422-01.jpg",
              --img_anchor = "NW",
              --font_style = 35,
              --font_path = "fonts/VT323-Regular.ttf",
              --word_wrap = true
              font_size = 25,
              font_path = font_path_2,
              draw_polygon = true,
              draw_image = true,
              rgb = options_UI:get_random_rgb(),
              rx = 5,
              ry = 5,
              segments = 10,
              line_width = 3


              }
          )

        }
  )
  
  accel_scl_idx = options_UI:add_area(
        {

          width_pct = 100,
          height_pct = 100,
          --min_pct = 90,
          fill = "",
          mode = "line",
          ext_anchor = "S",
          int_anchor = "",
          parent_idx = accel_idx,
          rgb = options_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          line_width = 3,
          widget = scale:new(
            {
              
              rgb = white,
              mode = "fill",

              rx = 5,
              ry = 5,
              segments = 5,

              --show_scroll_limit = true,
              progress = 0,
              has_scrollbar = true,
              --is_vertical = true,
              is_flipped = false,
              is_horizontal = true,
              --is_circular = true
              name = "tst_scl"
              

            }
          )

        }
  )

  friction_idx = options_UI:add_area(
        {

          width_pct = 100,
          height_pct = 100,
          --min_pct = 90,
          fill = "",
          mode = "line",
          ext_anchor = "S",
          int_anchor = "",
          parent_idx = accel_scl_idx,
          rgb = options_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          widget = button:new(
            {
              --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
              --text = tostring(i),
              
              text = ("Speed: %d"):format(SPEED_DATA.value),
              text_anchor = "C",
              mode = "line",
              --img = "armilk88-2049037086209040422-01.jpg",
              --img_anchor = "NW",
              --font_style = 35,
              --font_path = "fonts/VT323-Regular.ttf",
              --word_wrap = true
              font_size = 25,
              font_path = font_path_2,
              draw_polygon = true,
              draw_image = true,
              rgb = options_UI:get_random_rgb(),
              rx = 5,
              ry = 5,
              segments = 10,
              line_width = 3


              }
          )

        }
  )
  
  friction_scl_idx = options_UI:add_area(
        {

          width_pct = 100,
          height_pct = 100,
          --min_pct = 90,
          fill = "",
          mode = "line",
          ext_anchor = "S",
          int_anchor = "",
          parent_idx = friction_idx,
          rgb = white,
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          line_width = 3,
          widget = scale:new(
            {
              
              rgb = white,
              mode = "fill",

              rx = 5,
              ry = 5,
              segments = 5,

              --show_scroll_limit = true,
              progress = 0,
              has_scrollbar = true,
              --is_vertical = true,
              is_flipped = false,
              is_horizontal = true,
              --is_circular = true
              name = "tst_scl"
              

            }
          )

        }
  )

  jump_idx  = options_UI:add_area(
        {

          width_pct = 100,
          height_pct = 10,
          --min_pct = 90,
          fill = "",
          mode = "",
          ext_anchor = "",
          int_anchor = "NE",
          parent_idx = right_region,
          rgb = options_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          widget = button:new(
            {
              --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
              --text = tostring(i),
              
              text = "Jumping",
              text_anchor = "C",
              mode = "",
              --img = "armilk88-2049037086209040422-01.jpg",
              --img_anchor = "NW",
              --font_style = 35,
              --font_path = "fonts/VT323-Regular.ttf",
              --word_wrap = true
              font_size = 25,
              font_path = font_path_2,
              draw_polygon = true,
              draw_image = true,
              rgb = options_UI:get_random_rgb(),
              rx = 5,
              ry = 5,
              segments = 10,
              line_width = 3


              }
          )

        }
  )

  jump_hght_idx  = options_UI:add_area(
        {

          width_pct = 100,
          height_pct = 100,
          --min_pct = 90,
          fill = "",
          mode = "line",
          ext_anchor = "S",
          int_anchor = "",
          parent_idx = jump_idx,
          rgb = options_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          widget = button:new(
            {
              --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
              --text = tostring(i),
              
              text = ("Speed: %d"):format(SPEED_DATA.value),
              text_anchor = "C",
              mode = "line",
              --img = "armilk88-2049037086209040422-01.jpg",
              --img_anchor = "NW",
              --font_style = 35,
              --font_path = "fonts/VT323-Regular.ttf",
              --word_wrap = true
              font_size = 25,
              font_path = font_path_2,
              draw_polygon = true,
              draw_image = true,
              rgb = options_UI:get_random_rgb(),
              rx = 5,
              ry = 5,
              segments = 10,
              line_width = 3


              }
          )

        }
  )
  
  jump_scl_hght_idx = options_UI:add_area(
        {

          width_pct = 100,
          height_pct = 100,
          --min_pct = 90,
          fill = "",
          mode = "line",
          ext_anchor = "S",
          int_anchor = "",
          parent_idx = jump_hght_idx,
          rgb = white,
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          line_width = 3,
          widget = scale:new(
            {
              
              rgb = white,
              mode = "fill",

              rx = 5,
              ry = 5,
              segments = 5,

              --show_scroll_limit = true,
              progress = 0,
              has_scrollbar = true,
              --is_vertical = true,
              is_flipped = false,
              is_horizontal = true,
              --is_circular = true
              name = "tst_scl"
              

            }
          )

        }
  )

  jump_peak_idx  = options_UI:add_area(
        {

          width_pct = 100,
          height_pct = 100,
          --min_pct = 90,
          fill = "",
          mode = "line",
          ext_anchor = "S",
          int_anchor = "",
          parent_idx = jump_scl_hght_idx,
          rgb = options_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          widget = button:new(
            {
              --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
              --text = tostring(i),
              
              text = ("Speed: %d"):format(SPEED_DATA.value),
              text_anchor = "C",
              mode = "line",
              --img = "armilk88-2049037086209040422-01.jpg",
              --img_anchor = "NW",
              --font_style = 35,
              --font_path = "fonts/VT323-Regular.ttf",
              --word_wrap = true
              font_size = 25,
              font_path = font_path_2,
              draw_polygon = true,
              draw_image = true,
              rgb = options_UI:get_random_rgb(),
              rx = 5,
              ry = 5,
              segments = 10,
              line_width = 3


              }
          )

        }
  )
  
  jump_scl_peak_idx = options_UI:add_area(
        {

          width_pct = 100,
          height_pct = 100,
          --min_pct = 90,
          fill = "",
          mode = "line",
          ext_anchor = "S",
          int_anchor = "",
          parent_idx = jump_peak_idx,
          rgb = white,
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          line_width = 3,
          widget = scale:new(
            {
              
              rgb = white,
              mode = "fill",

              rx = 5,
              ry = 5,
              segments = 5,

              --show_scroll_limit = true,
              progress = 0,
              has_scrollbar = true,
              --is_vertical = true,
              is_flipped = false,
              is_horizontal = true,
              --is_circular = true
              name = "tst_scl"
              

            }
          )

        }
  )

  jump_desc_idx  = options_UI:add_area(
        {

          width_pct = 100,
          height_pct = 100,
          --min_pct = 90,
          fill = "",
          mode = "line",
          ext_anchor = "S",
          int_anchor = "",
          parent_idx = jump_scl_peak_idx,
          rgb = options_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          widget = button:new(
            {
              --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
              --text = tostring(i),
              
              text = ("Speed: %d"):format(SPEED_DATA.value),
              text_anchor = "C",
              mode = "line",
              --img = "armilk88-2049037086209040422-01.jpg",
              --img_anchor = "NW",
              --font_style = 35,
              --font_path = "fonts/VT323-Regular.ttf",
              --word_wrap = true
              font_size = 25,
              font_path = font_path_2,
              draw_polygon = true,
              draw_image = true,
              rgb = options_UI:get_random_rgb(),
              rx = 5,
              ry = 5,
              segments = 10,
              line_width = 3


              }
          )

        }
  )
  
  jump_scl_desc_idx = options_UI:add_area(
        {

          width_pct = 100,
          height_pct = 100,
          --min_pct = 90,
          fill = "",
          mode = "line",
          ext_anchor = "S",
          int_anchor = "",
          parent_idx = jump_desc_idx,
          rgb = white,
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          line_width = 3,
          widget = scale:new(
            {
              
              rgb = white,
              mode = "fill",

              rx = 5,
              ry = 5,
              segments = 5,

              --show_scroll_limit = true,
              progress = 0,
              has_scrollbar = true,
              --is_vertical = true,
              is_flipped = false,
              is_horizontal = true,
              --is_circular = true
              name = "tst_scl"
              

            }
          )

        }
  )

  --[[
    local speed_idx
    local accel_idx 
    local friction_idx
    local jump_hght_idx 
    local jump_peak_idx
    local jump_desc_idx

    local speed_scl_idx
    local accel_scl_idx
    local friction_scl_idx
    local jump_scl_hght_idx 
    local jump_scl_peak_idx
    local jump_scl_desc_idx
  ]]


  --local scl_custom = options_UI.widgets[custom_scl]
  --scl_custom:_set_progress(TOTAL_GIVEN)
  


  options_UI:draw()
end



local function hover_options()
  local options = {
    [easy_idx]   = DIFFICULTY._easy,
    [medium_idx] = DIFFICULTY._medium,
    [hard_idx]   = DIFFICULTY._hard,
    [custom_idx] = DIFFICULTY._custom,
  }


  for k, v in pairs(options) do
    --print(i)
    local button = options_UI.widgets[k]

      if button:_is_hovering_over(mx, my) then
       
          button.text_rgb = black
          button.rgb = white
          button.mode = "fill"
      

      else
        if v then
          button.text_rgb = black
          button.rgb = white
          button.mode = "fill"

        else
          button.text_rgb = white
          button.rgb = white
          button.mode = "line"
        end

      end
    

  end
end

local function hover_widget(dt, start_idx, end_idx)
  end_idx = end_idx or -1


  --[[
            --FLUX TWEEN OPTIONS
                linear 
                quadin quadout quadinout 
                cubicin cubicout cubicinout 
                quartin quartout quartinout 
                quintin quintout quintinout 
                expoin expoout expoinout 
                sinein sineout sineinout 
                circin circout circinout 
                backin backout backinout 
                elasticin elasticout elasticinout
            ]]
  if end_idx == -1 then
    local button = options_UI.widgets[start_idx]
    local og_area = options_UI.areas[start_idx]
    local og_area_w = og_area.x2 - og_area.x1
    local og_area_h = og_area.y2 - og_area.y1
    if button ~= "" then
      if button:_is_hovering_over(mx, my) then

        button.text_rgb = black
        button.rgb = white
        button.mode = "fill"

        


        FLUX.to(
              
                      button.area, 
                      0.5, 
                      {

                        x1 = og_area.x1 - og_area_w * 0.10,
                        y1 = og_area.y1 - og_area_h * 0.10,
                        x2 = og_area.x2 + og_area_w * 0.10,
                        y2 = og_area.y2 + og_area_h * 0.10

                      }
                    
                    )
      else

        button.text_rgb = white
        button.rgb = white
        button.mode = "line"

        FLUX.to(
              
                      button.area, 
                      0.5, 
                      {

                        x1 = og_area.x1,
                        y1 = og_area.y1,
                        x2 = og_area.x2,
                        y2 = og_area.y2

                      }
                    
                    )

      end     

    end


    
  else
      for i = start_idx, end_idx do
        --print(i)
        local button = options_UI.widgets[i]
        if button ~= "" then
          local idx = i - cell_start + 1
          local og_area = options_UI.areas[i]
          local og_area_w = og_area.x2 - og_area.x1
          local og_area_h = og_area.y2 - og_area.y1

          --print(i, button.area.x1, button.area.y1, button.area.x2, button.area.y2, button.area.x1, button.area.y1, button.area.x2, button.area.y2 )
          --local black = {r = 0, g = 0, b = 0, a = 1}
          --local white = {r = 1, g = 1, b = 1, a = 1}
          
          --if i ~= cell_selected then
            if button:_is_hovering_over(mx, my) then

              button.text_rgb = black
              button.rgb = white
              button.mode = "fill"
              
              
              --button.area = og_area
              FLUX.to(
              
                      button.area, 
                      0.5, 
                      {

                        x1 = og_area.x1 - og_area_w * 0.25,
                        y1 = og_area.y1 - og_area_h * 0.25,
                        x2 = og_area.x2 + og_area_w * 0.25,
                        y2 = og_area.y2 + og_area_h * 0.25

                      }
                    
                    )
            
              
            else

              button.text_rgb = white
              button.rgb = white
              button.mode = "line"

              --button.area = og_area
              FLUX.to(
              
                      button.area, 
                      0.5, 
                      {

                        x1 = og_area.x1,
                        y1 = og_area.y1,
                        x2 = og_area.x2,
                        y2 = og_area.y2

                      }
                    
                    )
              
            
            end
          --end
        end
        --print("Cell", i - cell_start + 1)
        
        

      end


      
    end
    FLUX.update(dt)
end



local function draw_widget(use_area, start_idx, end_idx)
  end_idx = end_idx or -1

  if end_idx == -1 then


    local button = options_UI.widgets[start_idx]
    local area = options_UI.areas[start_idx]
    if button ~= "" then
      if use_area then
          button.area = area
      end
      button:draw()
    end


  else 


    for i = start_idx, end_idx do
      local button = options_UI.widgets[i]
      local area = options_UI.areas[i]
      if button ~= "" then
        if use_area then
          button.area = area
        end
        button:draw()
      end
    end


  end
end

local function hover_btn(idx)
  local button = options_UI.widgets[idx]

  if button:_is_hovering_over(mx, my) then

    button.text_rgb = black
    button.rgb = white
    button.mode = "fill"

  else

    button.text_rgb = white
    button.rgb = white
    button.mode = "line"

  end

end

local function get_data()

  local DATAS = {
    SPEED_DATA,
    ACCEL_DATA,
    FRICTION_DATA,
    JUMP_PEAK_DATA,
    JUMP_HGHT_DATA,
    JUMP_DESC_DATA
  }

  local scls = {
    speed_scl_idx,
    accel_scl_idx,
    friction_scl_idx,
    jump_scl_peak_idx,
    jump_scl_hght_idx,
    jump_scl_desc_idx
  }

  local idxs = {
    speed_idx,
    accel_idx,
    friction_idx,
    jump_peak_idx,
    jump_hght_idx,
    jump_desc_idx
  }

  local txts = {
    "Speed: %.2f",
    "Accel: %.2f",
    "Friction: %.2f",
    "Peak: %.2f",
    "Height: %.2f",
    "Descent: %.2f"
  }
  return DATAS, scls, idxs, txts
end

local function init_UI()


  local DATAS, scls, idxs, txts = get_data()

  local RMB = 1
  for i = 1, #DATAS do
    local scl_custom = options_UI.widgets[scls[i]]
    local lbl_cells = options_UI.widgets[idxs[i]]
    
   
    scl_custom:_set_progress(DATAS[i].value/DATAS[i].max * 100)
    lbl_cells.text = (txts[i]):format(DATAS[i].value)
    --draw_widget(true, idxs[i])
    --draw_widget(true, scls[i])
  end

  

  

end



local function draw_UI()
  --draw_widget(jump_idx)
  local DATAS, scls, idxs, txts = get_data()
  
  local RMB = 1
  for i = 1, #DATAS do
    local scl_custom = options_UI.widgets[scls[i]]
    local lbl_cells = options_UI.widgets[idxs[i]]
    
   
    --scl_custom:_set_progress(DATAS[i].value/DATAS[i].max * 100)
    --lbl_cells.text = (txts[i]):format(DATAS[i].value)
    draw_widget(true, idxs[i])
    draw_widget(true, scls[i])
  end

  

  
end

local function get_slider_data(_DATA, custom_scl)
  return clamp(
                _DATA.min + custom_scl:_get_progress()/100 * (_DATA.max - _DATA.min), 
                _DATA.max,
                _DATA.min
            )
end

local function update_UI()
  mx, my = love.mouse.getPosition()
  --[[
    local speed_idx
    local accel_idx 
    local friction_idx
    local jump_hght_idx 
    local jump_peak_idx
    local jump_desc_idx

    local speed_scl_idx
    local accel_scl_idx
    local friction_scl_idx
    local jump_scl_hght_idx 
    local jump_scl_peak_idx
    local jump_scl_desc_idx
  ]]
  local DATAS, scls, idxs, txts = get_data()

  local RMB = 1
  for i = 1, #DATAS do
    local scl_custom = options_UI.widgets[scls[i]]
    local lbl_cells = options_UI.widgets[idxs[i]]
    
    


    if scl_custom:_is_mouse_down(mx, my, RMB) then
    
      scl_custom:_drag_value(mx, my) 
  
      DATAS[i].value = get_slider_data(DATAS[i], scl_custom)
      lbl_cells.text = (txts[i]):format(DATAS[i].value)

    end
  end

end



function PAUSE_SCENE:init()
  --decide_difficulty()
  setup_UI()
  init_UI()
  draw_UI()
  --raw_widget(true, switch_idx)
  --draw_widget(true, speed_idx)
  --draw_widget(true, speed_scl_idx)
  --select_mode()
end

function PAUSE_SCENE:enter()
  --called each time the scene is entered
  setup_UI()
  init_UI()
  draw_UI()

  
  --select_mode()
  --update_UI()
  -- this is to prevent interpolation from the top of the screen
  --[[
  draw_widget(true, title_region)
  draw_widget(true, cells_region)
  draw_widget(true, easy_idx)
  draw_widget(true, medium_idx)
  draw_widget(true, hard_idx)
  draw_widget(true, custom_idx)
  draw_widget(true, switch_idx) 
  draw_widget(true, custom_scl) 
  ]]
end

function PAUSE_SCENE:update(dt)
  

  update_UI()
  hover_widget(dt, switch_idx)
  
  
  --hover_widget(dt, easy_idx)
  --hover_widget(dt, medium_idx)
  --hover_widget(dt, hard_idx)
  --hover_widget(dt, custom_idx)
  --hover_btn(easy_idx)
  --hover_btn(medium_idx)
  --hover_btn(custom_idx)
  --hover_options()
  

end

function PAUSE_SCENE:draw()
  options_UI:draw()

  --select_mode()
  draw_widget(true, title_region)
  draw_widget(true, switch_idx)
  draw_widget(true, move_idx)
  draw_widget(true, jump_idx)
  draw_UI()
  --draw_widget(true, cells_region)
  --draw_widget(false, easy_idx)
  --draw_widget(false, medium_idx)
  --draw_widget(false, hard_idx)
  --draw_widget(false, custom_idx)
  --draw_widget(false, speed_idx) 
  --draw_widget(true, speed_scl_idx) 
  

  
end


function PAUSE_SCENE:keypressed(key, code)

  
end

function PAUSE_SCENE:mousepressed(x, y, button, istouch)
  local RMB_down = button == 1
  local LMB_down = button == 2

  --local easy_btn   = options_UI.widgets[easy_idx]
  --local medium_btn = options_UI.widgets[medium_idx]
  --local hard_btn   = options_UI.widgets[hard_idx] 
  --local custom_btn = options_UI.widgets[custom_idx] 
  local btn_switch = options_UI.widgets[switch_idx]

  local lbl_cells = options_UI.widgets[speed_idx]

  if RMB_down then
    

    if btn_switch:_is_hovering_over(mx, my) then
      
      GAMESTATE.switch(MENU_SCENE)
    end


  end

  
end

function PAUSE_SCENE:wheelmoved(x, y)
    

    
    
end

function PAUSE_SCENE:resize(w, h)
  options_UI.areas[full_region] = {x1 = 0, y1 = 0, x2 = SCREEN_WIDTH, y2 = SCREEN_HEIGHT}
  

  options_UI:update_areas()
  options_UI:draw()
end

function PAUSE_SCENE:keyreleased(key, code)
  --if key == 'return' then
      --GAMESTATE.switch(GAME_SCENE)
  --end
end