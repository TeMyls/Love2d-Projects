---------------------------------------------------------------------------------------------------------------
-- Template Menu - with all? the things HUMP's gamestate allows 
---------------------------------------------------------------------------------------------------------------

function TEMPLATE_SCENE:init()
    -- runs only once
end

function TEMPLATE_SCENE:enter()
    -- runs every time the scene is entered

end

function TEMPLATE_SCENE:leave()
    -- runs every time the scene is exited
  
end



function TEMPLATE_SCENE:update(dt)


end

function TEMPLATE_SCENE:draw()
  

end

function TEMPLATE_SCENE:wheelmoved(x, y)
  
end

function TEMPLATE_SCENE:keyreleased(key, code)

end

function TEMPLATE_SCENE:mousepressed(x, y, button, istouch)

end

function TEMPLATE_SCENE:resize(w, h)

end

