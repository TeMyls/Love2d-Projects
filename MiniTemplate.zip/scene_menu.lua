---------------------------------------------------------------------------------------------------------------
-- The Starting Menu
---------------------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------------------
-- The Starting Menu
---------------------------------------------------------------------------------------------------------------

local button = require "my_lib.button"
local scale = require "my_lib.scale"
local GUIM = require "my_lib.GUIM" 
local menu_UI = nil
local r, g, b, a = love.math.colorFromBytes(0, 0, 0, 1)--(172, 170, 189)

local font_path_1 = "fonts//VT323-Regular.ttf"
local font_path_2 = "fonts//Kaph-Regular.ttf"
local font_path_3 = "font//comic_neue_bold_19.ttf"

local full_region = nil
local main_region = nil
local mode_region = nil
local play_idx = nil
local title_region = nil
local options_idx = nil
local how_idx = nil

local mx = -1
local my = -1

local black = {r = 0, g = 0, b = 0, a = 1}
local white = {r = 1, g = 1, b = 1, a = 1}
local gray  = {r = 0.5, g = 0.5, b = 0.5, a = 1}




local function setup_UI()

  menu_UI = GUIM:new()
  menu_UI.show_index = false
  menu_UI.show_widget = false
  local k = ""
  full_region = menu_UI:add_area(
            {
              area = {
              x1 = 0,
              y1 = 0,
              x2 = SCREEN_WIDTH,
              y2 = SCREEN_HEIGHT
              },
              fill = "",
              mode = "fill",
              ext_anchor = "",
              int_anchor = "N",
              parent_idx = nil,
              rgb = black
              --[[
              rgb = {
                r = r,
                g = g,
                b = b,
                a = a
              }]]

            }
  )

  -- the play area
  main_region = menu_UI:add_area(
        {

          width_pct = 90,
          height_pct = 90,
          --min_pct = 90,
          fill = "",
          mode = "fill",
          ext_anchor = "",
          int_anchor = "C",
          parent_idx = full_region,
          rgb = black,
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10

        }

  )

  -- the play area
  title_region = menu_UI:add_area(
        {

          width_pct = 100,
          height_pct = 35,
          --min_pct = 90,
          fill = "",
          mode = "",
          ext_anchor = "",
          int_anchor = "N",
          parent_idx = main_region,
          rgb = menu_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          widget = button:new(
            {
              --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
              --text = tostring(i),

              text = "Minimal Template",
              text_anchor = "C",
              mode = "line",
              --img = "armilk88-2049037086209040422-01.jpg",
              --img_anchor = "NW",
              --font_style = 35,
              --font_path = "fonts/VT323-Regular.ttf",
              --word_wrap = true
              font_size = 55,
              font_path = font_path_2,
              draw_polygon = true,
              draw_image = true,
              rgb = white,
              rx = 5,
              ry = 5,
              segments = 10,
              line_width = 3


              }
          )

        }

  )

  mode_region = menu_UI:add_area(
        {

          width_pct = 50,
          height_pct = 65,
          --min_pct = 90,
          fill = "",
          mode = "",
          ext_anchor = "",
          int_anchor = "S",
          parent_idx = main_region,
          rgb = menu_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10


        }

  )

  local play_region = menu_UI:add_area(
        {

          width_pct = 100,
          height_pct = 25,
          --min_pct = 90,
          fill = "",
          mode = "",
          ext_anchor = "",
          int_anchor = "N",
          parent_idx = mode_region,
          rgb = menu_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth"

          --line_width = 10
          

        }

  )

  play_idx = menu_UI:add_area(
        {

          width_pct = 65,
          height_pct = 90,
          --min_pct = 90,
          fill = "",
          mode = "",
          ext_anchor = "",
          int_anchor = "C",
          parent_idx = play_region,
          rgb = menu_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          widget = button:new(
            {
              --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
              --text = tostring(i),

              text = "PLAY",
              text_anchor = "C",
              mode = "line",
              --img = "armilk88-2049037086209040422-01.jpg",
              --img_anchor = "NW",
              --font_style = 35,
              --font_path = "fonts/VT323-Regular.ttf",
              --word_wrap = true
              font_size = 25,
              font_path = font_path_2,
              draw_polygon = true,
              draw_image = true,
              rgb = white,
              rx = 5,
              ry = 5,
              segments = 10,
              line_width = 3


              }
          )

        }

  )

  
  local options_region = menu_UI:add_area(
        {

          width_pct = 100,
          height_pct = 100,
          --min_pct = 90,
          fill = "",
          mode = "",
          ext_anchor = "SE",
          int_anchor = "",
          parent_idx = play_region,
          rgb = menu_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          

        }

  )

  options_idx = menu_UI:add_area(
        {

          width_pct = 65,
          height_pct = 90,
          --min_pct = 90,
          fill = "",
          mode = "",
          ext_anchor = "",
          int_anchor = "C",
          parent_idx = options_region,
          rgb = menu_UI:get_random_rgb(),
          
          line_style = "smooth",

          --line_width = 10
          widget = button:new(
            {
              --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
              --text = tostring(i),

              text = "OPTIONS",
              text_anchor = "C",
              mode = "line",
              --img = "armilk88-2049037086209040422-01.jpg",
              --img_anchor = "NW",
              --font_style = 35,
              --font_path = "fonts/VT323-Regular.ttf",
              --word_wrap = true
              font_size = 25,
              font_path = font_path_2,
              draw_polygon = true,
              draw_image = true,
              rgb = white,
              rx = 5,
              ry = 5,
              segments = 10,
              line_width = 3
              


              }
          )

        }

  )

  local how_region = menu_UI:add_area(
        {

          width_pct = 100,
          height_pct = 100,
          --min_pct = 90,
          fill = "",
          mode = "",
          ext_anchor = "SE",
          int_anchor = "",
          parent_idx = options_region,
          rgb = menu_UI:get_random_rgb(),
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          

        }

  )

  how_idx = menu_UI:add_area(
        {

          width_pct = 65,
          height_pct = 90,
          --min_pct = 90,
          fill = "",
          mode = "",
          ext_anchor = "",
          int_anchor = "C",
          parent_idx = how_region,
          rgb = menu_UI:get_random_rgb(),
          
          line_style = "smooth",

          --line_width = 10
          widget = button:new(
            {
              --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
              --text = tostring(i),

              text = "Instructions",
              text_anchor = "C",
              mode = "line",
              --img = "armilk88-2049037086209040422-01.jpg",
              --img_anchor = "NW",
              --font_style = 35,
              --font_path = "fonts/VT323-Regular.ttf",
              --word_wrap = true
              font_size = 25,
              font_path = font_path_2,
              draw_polygon = true,
              draw_image = true,
              rgb = white,
              rx = 5,
              ry = 5,
              segments = 10,
              line_width = 3
              


              }
          )

        }

  )
  
  menu_UI:draw()
end

local function hover_widget(dt, start_idx, end_idx)
  end_idx = end_idx or -1


  --[[
            --FLUX TWEEN OPTIONS
                linear 
                quadin quadout quadinout 
                cubicin cubicout cubicinout 
                quartin quartout quartinout 
                quintin quintout quintinout 
                expoin expoout expoinout 
                sinein sineout sineinout 
                circin circout circinout 
                backin backout backinout 
                elasticin elasticout elasticinout
            ]]
  if end_idx == -1 then
    local button = menu_UI.widgets[start_idx]
    local og_area = menu_UI.areas[start_idx]
    local og_area_w = og_area.x2 - og_area.x1
    local og_area_h = og_area.y2 - og_area.y1
    if button ~= "" then
      if button:_is_hovering_over(mx, my) then

        button.text_rgb = black
        button.rgb = white
        button.mode = "fill"
        FLUX.to(
              
                      button.area, 
                      0.5, 
                      {

                        x1 = og_area.x1 - og_area_w * 0.10,
                        y1 = og_area.y1 - og_area_h * 0.10,
                        x2 = og_area.x2 + og_area_w * 0.10,
                        y2 = og_area.y2 + og_area_h * 0.10

                      }
                    
                    )
      else

        button.text_rgb = white
        button.rgb = white
        button.mode = "line"

        FLUX.to(
              
                      button.area, 
                      0.5, 
                      {

                        x1 = og_area.x1,
                        y1 = og_area.y1,
                        x2 = og_area.x2,
                        y2 = og_area.y2

                      }
                    
                    )

      end     

    end


    
  


      
    end
    FLUX.update(dt)
end

local function draw_widget(use_area, start_idx, end_idx)
  end_idx = end_idx or -1

  --[[
            --FLUX TWEEN OPTIONS
                linear 
                quadin quadout quadinout 
                cubicin cubicout cubicinout 
                quartin quartout quartinout 
                quintin quintout quintinout 
                expoin expoout expoinout 
                sinein sineout sineinout 
                circin circout circinout 
                backin backout backinout 
                elasticin elasticout elasticinout
            ]]
  if end_idx == -1 then


    local button = menu_UI.widgets[start_idx]
    local area = menu_UI.areas[start_idx]
    if button ~= "" then
      if use_area then
          button.area = area
      end
      button:draw()
    end


  else 


    for i = start_idx, end_idx do
      local button = menu_UI.widgets[i]
      local area = menu_UI.areas[i]
      if button ~= "" then
        if use_area then
          button.area = area
        end
        button:draw()
      end
    end


  end
end

local function hover_btn(idx)
  local button = menu_UI.widgets[idx]

  if button:_is_hovering_over(mx, my) then

      button.text_rgb = black
      button.rgb = white
      button.mode = "fill"

    else

      button.text_rgb = white
      button.rgb = white
      button.mode = "line"

    end
end

function MENU_SCENE:init()
  print("ENTERED")
  
  setup_UI()

  --menu_UI.widgets[play_idx].area = menu_UI.areas[play_idx]
  
end



function MENU_SCENE:update(dt)
  mx, my = love.mouse.getPosition()
  --hover_btn(play_idx)
  --hover_btn(options_idx)
  hover_widget(dt, play_idx)
  hover_widget(dt, options_idx)
  hover_widget(dt, how_idx)
end



function MENU_SCENE:draw()
  
  menu_UI:draw()

  --because show_widget is disabled, in order to tween
  draw_widget(false, play_idx)
  draw_widget(false, options_idx)
  draw_widget(true, title_region)
  draw_widget(false, how_idx)


end

function MENU_SCENE:leave()

  
end

function MENU_SCENE:enter()
  setup_UI()
  -- this is to prevent interpolation from the top of the screen
  draw_widget(true, play_idx)
  draw_widget(true, options_idx)
  draw_widget(true, title_region)
  draw_widget(true, how_idx)
  -- called everytime scene is entered
  --menu_UI.areas[1] = {x1 = 0, y1 = 0, x2 = SCREEN_WIDTH, y2 = SCREEN_HEIGHT}
  

  --menu_UI:update_areas()
  --menu_UI:draw()
  
end

function MENU_SCENE:mousepressed(x, y, button, istouch)
  local RMB_down = button == 1
  local LMB_down = button == 2


  --if play_idx then
  if RMB_down then
    if menu_UI.widgets[play_idx]:_is_hovering_over(mx, my) then
      
      GAMESTATE.switch(GAME_SCENE)
    elseif menu_UI.widgets[options_idx]:_is_hovering_over(mx, my) then
      GAMESTATE.switch(PAUSE_SCENE)
    elseif menu_UI.widgets[how_idx]:_is_hovering_over(mx, my) then
      GAMESTATE.switch(HOW_SCENE)
    end

  end
  --end

  
end

function MENU_SCENE:resize(w, h)
  menu_UI.areas[1] = {x1 = 0, y1 = 0, x2 = SCREEN_WIDTH, y2 = SCREEN_HEIGHT}
  

  menu_UI:update_areas()
  menu_UI:draw()


end

