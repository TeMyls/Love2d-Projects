-- Stuff I've written or rewritten
local angle_convert = require "my_lib.angle_convert"
local transformer = require "my_lib.transformer"
local collider = require "my_lib.collider"
local raycast = require "my_lib.raycast"
local easings = require "my_lib.easings"

-- bump.lua - A Collision-detection library in primarily focused on
--    axis-aligned bounding box, or AABB collision
--    this is focused on rectangles, making it ideal for tile based games   
-- https://github.com/kikito/bump.lua
local bump = require 'lib.bump'
local World = bump.newWorld()


-- Jumper - Pathfinding Library for Lua
-- https://github.com/Yonaba/Jumper
local Grid = require ("lib.jumper.grid")
local Pathfinder = require ("lib.jumper.pathfinder")


-- classic - Class/Object Orientated Programming(OOP) Library for Lua
-- https://github.com/rxi/classic
local Object = require("lib.classic")
ENTITY = Object.extend(Object)


function ENTITY:new(position_table,dimesion_table,hp,img,quad_x,quad_y,in_world,group)
  --helpers
  self.transformer = transformer:new()
  self.collider = collider:new()
  self.raycast = raycast:new()
  self.angle_convert = angle_convert:new()
  self.easings = easings:new()



  --general
  self.position = VECTOR2(position_table.x, position_table.y)
  self.velocity = VECTOR2.zero
  self.dimension = VECTOR2(dimesion_table.w, dimesion_table.h)
  self.direction =  VECTOR2.zero
  
  --if acceleration or friction is set to one it will immediately start and stop
  self.friction = 1
  self.acceleration = 1


  --either rectangle, circle, or lines
  self.shape = ""
  self.lines = {}


  --quad positions
  self.quad_x = quad_x 
  self.quad_y = quad_y 
 
  
  self.img = img 
  self.quad = nil
  if self.img ~= nil then
    self.img = love.graphics.newImage(img)
    self.quad = love.graphics.newQuad(self.quad_x,self.quad_y,self.dimension.x,self.dimension.y,self.img)
  end


  self.og_hp = hp
  self.hp = hp 
  --tile based stuff
  self.tile_path = {}
  self.canceled_path = false
  self.start_cell_x = 0
  self.start_cell_y = 0
  self.end_cell_x = 0
  self.end_cell_y = 0
  self.map_reference = {}
  self.delta_time = 0

  
  --tweens and stuff
  self.is_tweening = false
  self.og_tween_time = .3
  self.tween_time = self.og_tween_time
  self.timer_tile_button = TIMER.new()
  self.timer_tile_click = TIMER.new()
  
  --mode bools
  self.mouse_tile_input = false
  self.button_tile_input = false
  self.plaforming = false
  self.grounded = false

  --animation without the anim8 library
  --time is time to next frame in seconds, quad_x and quad_y are the starting quads
  -- https://love2d.org/wiki/Tutorial:Animation
  -- https://love2d.org/wiki/love.graphics.newQuad
  self.sample_anim = {time = .125, quad_x = 0, quad_y = 0, og_time = .125, og_quad_x = 0, og_quad_y = 0, frames = 4, name = "walk"}
  self.frame_size = nil
  
 
  --orientation
  --flipx and flipy
  self.fx = 1
  self.fy = 1
  
  
  self.sin = 0
  self.cos = 0
  --mouse coords
  self.mx = 0
  self.my = 0
  self.mouse_vector = VECTOR2.zero
  
  
  --movement code
  self.jump_height = 48
  self.jump_time_to_peak = 0.5
  self.jump_time_to_descent = 0.8

  local jv = ((2.0 * self.jump_height)/ self.jump_time_to_peak) * -1.0
  local jg = ((-2.0 * self.jump_height)/ (self.jump_time_to_peak*self.jump_time_to_peak)) * -1.0
  local fg = ((-2.0 * self.jump_height)/ (self.jump_time_to_descent*self.jump_time_to_descent)) * -1.0

  self.jump_velocity = jv
  self.jump_gravity =  jg
  self.fall_gravity = fg


  self.last_y = 0
  self.rotation_speed = 300
  self.move_speed = 150
  

  --calc in degrees and converted to radians
  self.angle = 0
  
  
  --terminal velocity
  self.terminal_velocity = fg * 1.5
  
  --classifcation
  if in_world == true then
    World:add(self, self.position.x,self.position.y,self.dimension.x,self.dimension.y)
  end
  
  if group ~= nil then
    table.insert(group,self)
  end
  
  
  self.hitbox = {
    self.position.x                   , self.position.y, 
    self.position.x                   , self.position.y + self.dimension.y,
    
    self.position.x + self.dimension.x, self.position.y + self.dimension.y,
    self.position.x + self.dimension.x,  self.position.y
  
  
}

  self.line = {
    x1 = 0,
    y1 = 0,
    x2 = 0,
    y2 = 0,
    length = 10
  }
  
end

function ENTITY:in_bounds(x, y, grid_w, grid_h)
  return 0 < x and x < grid_w  and  0 < y and x < grid_h 
end

function ENTITY:array2d_to_world(x, y)
  local _x = (x - 1) * TILESIZE
  local _y = (y - 1) * TILESIZE
  return _x , _y
end

function ENTITY:world_to_array2d(x, y)
  local _x = math.floor(((x/WORLD_LEVEL_WIDTH) * LEVEL_WIDTH)) + 1
  local _y = math.floor(((y/WORLD_LEVEL_HEIGHT) * LEVEL_HEIGHT)) + 1
  return _x , _y
end

function ENTITY:follow_target_tile(dt, walkable_tile, a_vector)
  
  self.mouse_tile_input = true
  local array_in_bounds = false
  --real World coordinates getting translated into array coords
  local start_cell_x, start_cell_y = self:world_to_array2d(self.position.x, self.position.y)
  local end_cell_x,end_cell_y = self:world_to_array2d(a_vector.x, a_vector.y)
  local player_tile = 9
  local new_coords = {}
  if love.mouse.isDown(1) then
    if #self.tile_path == 0 then

      array_in_bounds = self:in_bounds(end_cell_x, end_cell_y, LEVEL_WIDTH, LEVEL_HEIGHT)

    end
  end

    -- Pretty-printing the results
  if #self.tile_path == 0 then
    if array_in_bounds then

      local myFinder = Pathfinder(Grid(LEVEL), 'ASTAR', walkable_tile)
      local path = myFinder:getPath(start_cell_x, start_cell_y, end_cell_x, end_cell_y)
      -- Orthogonal means no diagonals in the path
      --myFinder:setMode('ORTHOGONAL')
      
      if path then
        
        
        --print(path:nodes())
        --print(('Path found! Length: %.2f'):format(path:getLength()))
        for node, count in path:nodes() do
          local x_,y_ = self:array2d_to_world(node:getX(),node:getY())
          table.insert(self.tile_path,{x_,y_})
          --print(('Step: %d - x: %d - y: %d'):format(count, node:getX(), node:getY()))
        end
        new_coords = table.remove(self.tile_path,1)
        local prev_array_x, prev_array_y = self:world_to_array2d(self.position.x,self.position.y)
        --LEVEL[prev_array_y][prev_array_x] = walkable_tile

        -- the function below was used, until I realized the player's tile was being added to the LEVEL making them avoid the last tile they were on
        local move_to = function () 
      
          --self.position.x = LUME.round((self.position.x/(LEVEL_WIDTH * TILESIZE)) * (LEVEL_WIDTH)) * TILESIZE
          --self.position.y = LUME.round((self.position.y/(LEVEL_HEIGHT * TILESIZE)) * (LEVEL_HEIGHT)) * TILESIZE
          
          --local current_array_x, current_array_y = self:world_to_array2d(self.position.x,self.position.y)
          
          --LEVEL[current_array_y][current_array_x] = player_tile
        end

        --self.position.x = self.easings:interpolate(self.position.x, new_coords[1], self.tween_time/self.og_tween_time)
        --self.position.y = self.easings:interpolate(self.position.y, new_coords[2], self.tween_time/self.og_tween_time)

        -- using FLUX
        FLUX.to(self.position, self.og_tween_time, {x = new_coords[1], y = new_coords[2]})--:oncomplete(move_to)
        
        -- using Hump TIMER
        --self.timer_tile_click:tween(self.og_tween_time, self.position, VECTOR2(new_coords[1], new_coords[2]), 'linear')--, move_to) 
        --TIMER.tween(self.og_tween_time, self.position, VECTOR2(new_coords[1], new_coords[2]), 'linear')--, move_to)

        
      end
    end
  elseif #self.tile_path >= 0  then
    
    
    self.tween_time = self.tween_time - dt
    if self.tween_time <= 0 then
        self.tween_time = self.og_tween_time
        new_coords = table.remove(self.tile_path, 1)
        local prev_array_x, prev_array_y = self:world_to_array2d(self.position.x,self.position.y)
        --LEVEL[prev_array_y][prev_array_x] = walkable_tile

        local move_to = function () 
          
          if self.canceled_path then

            LUME.clear(self.tile_path)
            self.canceled_path = false

          end

          --[[
          -- this chunk of code use to add th player to it's new position in an array
          if not self.canceled_path then 
            --self.position.x = LUME.round((self.position.x/(LEVEL_WIDTH * TILESIZE)) * (LEVEL_WIDTH)) * TILESIZE
            --self.position.y = LUME.round((self.position.y/(LEVEL_HEIGHT * TILESIZE)) * (LEVEL_HEIGHT)) * TILESIZE

            local current_array_x, current_array_y = self:world_to_array2d(self.position.x,self.position.y)
            --LEVEL[current_array_y][current_array_x] = player_tile
          else
            LUME.clear(self.tile_path)
            --self.position.x = LUME.round((self.position.x/(LEVEL_WIDTH * TILESIZE)) * (LEVEL_WIDTH)) * TILESIZE
            --self.position.y = LUME.round((self.position.y/(LEVEL_HEIGHT * TILESIZE)) * (LEVEL_HEIGHT)) * TILESIZE
            --LEVEL[prev_array_y][prev_array_x] = walkable_tile
            local current_array_x, current_array_y = self:world_to_array2d(self.position.x,self.position.y)
            self.canceled_path = false
            --LEVEL[current_array_y][current_array_x] = player_tile
          end
          ]]

        end

        

        -- using FLUX
        FLUX.to(self.position, self.og_tween_time, {x = new_coords[1], y = new_coords[2]}):oncomplete(move_to)
        
        -- using Hump TIMER Tween
        --self.timer_tile_click:tween(self.og_tween_time, self.position, VECTOR2(new_coords[1], new_coords[2]), 'linear', move_to) 
        --TIMER.tween(self.og_tween_time, self.position, VECTOR2(new_coords[1], new_coords[2]), 'linear', move_to)
        
        
   
    end
    
  end
  if #new_coords > 0 then
    --custom
    --self.position.x = self.easings:interpolate(self.position.x, new_coords[1], self.tween_time/self.og_tween_time) 
    --self.position.y = self.easings:interpolate(self.position.y, new_coords[2], self.tween_time/self.og_tween_time) 
  end

  --using FLUX
  FLUX.update(dt)

  --using Hump TIMER
 -- self.timer_tile_click:update(dt)
  --TIMER.update(dt)
  
end

function ENTITY:tile_button_movement(dt,walkable_tile,unreachable_tile)
  self.button_tile_input = true

  local up = {love.keyboard.isDown('up','w'), {x = 0, y = -1}}
  local down = {love.keyboard.isDown('down','s'), {x = 0, y = 1}}
  local right = {love.keyboard.isDown('right','d'), {x = 1, y = 0}}
  local left = {love.keyboard.isDown('left','a'), {x = -1, y = 0}} 




  local key_inputs = {
    up,
    down,
    right,
    left
  }



  local player_tile = 9
  
  local cur_x = self.position.x
  local cur_y = self.position.y

  local next_x = 0
  local next_y = 0
  local prev_array_x, prev_array_y = 0, 0
  local next_array_x, next_array_y = 0, 0

  if not self.is_tweening then
    for i = 1, #key_inputs do
      local key_pressed = key_inputs[i][1]
      if key_pressed then

        local direction = key_inputs[i][2]
        next_x = cur_x + direction.x * TILESIZE
        next_y = cur_y + direction.y * TILESIZE
        local world_in_bounds = next_x <= WORLD_LEVEL_WIDTH and next_x >= 0 and next_y <= WORLD_LEVEL_HEIGHT and next_y >= 0
        
        local prev_array_x, prev_array_y = self:world_to_array2d(cur_x,cur_y)
        local next_array_x, next_array_y = self:world_to_array2d(next_x, next_y)

        local array_in_bounds = self:in_bounds(next_array_x, next_array_x, LEVEL_WIDTH, LEVEL_HEIGHT)
        local is_valid = true 
        if array_in_bounds then
          is_valid = LEVEL[next_array_y][next_array_x] ~= unreachable_tile
        end
        if world_in_bounds and is_valid and array_in_bounds then 
          cur_x = next_x 
          cur_y = next_y 
          self.is_tweening = true
          self.tween_time = self.og_tween_time
          --LEVEL[prev_array_y][prev_array_x] = walkable_tile
          --LEVEL[next_array_y][next_array_x] = player_tile
          --LEVEL[array_y][array_x] = 9
        end

        break
      end
    end

    
  end
    

  --local num = ("iNPUTTED: %.2f"..tostring(has_inputted))
  if self.is_tweening and {cur_x, cur_y} ~= {-1, -1} then
      if self.tween_time == self.og_tween_time then
        local move_to = function ()
            self.position = (VECTOR2(self:world_to_array2d(self.position:unpack())) - VECTOR2(1,1)) * TILESIZE
            
          end

          
          -- using FLUX
          FLUX.to(self.position, self.tween_time, VECTOR2(cur_x, cur_y)):oncomplete(move_to)
        
          -- using Hump TIMER Tween
          --self.timer_tile_button:tween(self.tween_time, self.position, VECTOR2(cur_x, cur_y), 'linear', move_to)
          --TIMER.tween(self.tween_time, self.position, VECTOR2(cur_x, cur_y), 'linear', move_to)
        
      end

      self.tween_time = self.tween_time - dt
      if self.tween_time <= 0 then
        self.is_tweening = false
        self.tween_time = self.og_tween_time
      end
    end
    -- using FLUX
    FLUX.update(dt)

    -- using Hump TIMER
    --self.timer_tile_button:update(dt)
    --TIMER.update(dt)

end



function ENTITY:animate(dt, anim_array, quad, dir)
  dir = dir or 1
  
  
  if anim_array.frames ~= 1 then
    anim_array.time = anim_array.time - dt
  end
    
  if anim_array.time <= 0  then
        
      anim_array.quad_x = anim_array.quad_x + 1 * dir
      anim_array.time = anim_array.og_time
      if anim_array.quad_x == anim_array.frames then
        anim_array.quad_x = anim_array.og_quad_x
        
      end
      
  end

  quad:setViewport(
    self.frame_size * anim_array.quad_x,
    self.frame_size * anim_array.quad_y,
    self.frame_size,
    self.frame_size
    )
  
end

function ENTITY:update_line_angle(dt)
  --shows the actually line the players pointing at an angle
  self.line.x1 = self.position.x + self.dimension.x/2 
  self.line.y1 = self.position.y + self.dimension.y/2 
  self.line.x2 = self.position.x + self.dimension.x/2 + self.line.length*self.cos
  self.line.y2 = self.position.y + self.dimension.y/2 + self.line.length*self.sin
end

function ENTITY:follow_target(dt, a_vector, is_tiled)
  --angle calculation without LUME
  --local angle = math.atan2(a_vector.y - (self.position.x + self.dimension.x/2),a_vector.x - (self.position.x + self.dimension.x/2))
  local angle = LUME.angle(self.position.x + (self.dimension.x/2),self.position.y + (self.dimension.y/2), a_vector.x, a_vector.y)
  self.angle = self.angle_convert:radians_to_degrees(angle)
    

  --stop moving if certain distance from target
  if not self.collider:point_circle(self.position.x + (self.dimension.x/2), self.position.y + (self.dimension.y/2), a_vector.x, a_vector.y, 10) then

    self.sin = math.sin(angle)
    self.cos = math.cos(angle)
    self.velocity.x = LUME.lerp(
                                self.velocity.x, 
                                self.cos *  self.move_speed, 
                                self.acceleration
                              )
    self.velocity.y = LUME.lerp(
                                self.velocity.y, 
                                self.sin *  self.move_speed, 
                                self.acceleration
                              )
   
  else

    self.velocity.y = LUME.lerp(
                                self.velocity.y, 
                                0, 
                                self.friction
                              )
    self.velocity.x = LUME.lerp(
                                self.velocity.x, 
                                0, 
                                self.friction
                              )
  end

  self:collide(dt, is_tiled)
end

function ENTITY:tank_movement(dt)
  -- Tank movement where up/w and down/s keys control foward and backwards movement
  -- and the right and left control angle
  local up = love.keyboard.isDown('up','w')
  local down = love.keyboard.isDown('down','s')
  local right = love.keyboard.isDown('right','d')
  local left = love.keyboard.isDown('left','a')
  
  if right then
    
    
    self.angle = self.angle + self.rotation_speed * dt 
    if self.angle > 360 then
      self.angle = 0
    end
   
  elseif left then
   
    self.angle = self.angle - self.rotation_speed *dt 
    if self.angle < 0 then
      self.angle = 360
    end
    
  end

  local angle = self.angle_convert:degrees_to_radians(self.angle)
  self.sin = math.sin(angle)
  self.cos = math.cos(angle)

  
  local foward_y = math.sin(self.angle_convert:degrees_to_radians(self.angle))
  local foward_x = math.cos(self.angle_convert:degrees_to_radians(self.angle))
  
  local left_y = math.sin(self.angle_convert:degrees_to_radians(self.angle - 90))
  local left_x = math.cos(self.angle_convert:degrees_to_radians(self.angle - 90))
  
  local right_y = math.sin(self.angle_convert:degrees_to_radians(self.angle + 90))
  local right_x = math.cos(self.angle_convert:degrees_to_radians(self.angle + 90))
  
  local back_y = math.sin(self.angle_convert:degrees_to_radians(self.angle - 180))
  local back_x = math.cos(self.angle_convert:degrees_to_radians(self.angle - 180))
  
  if up then

    --applying acceleration
    self.velocity.y = LUME.lerp(
                                self.velocity.y, 
                                foward_y * self.move_speed, 
                                self.acceleration
                              )

    self.velocity.x = LUME.lerp(
                                self.velocity.x, 
                                foward_x * self.move_speed, 
                                self.acceleration
                              )

    
  elseif down then

    self.velocity.y = LUME.lerp(
                                self.velocity.y, 
                                back_y * self.move_speed, 
                                self.acceleration
                              )

    self.velocity.x = LUME.lerp(
                                self.velocity.x, 
                                back_x * self.move_speed, 
                                self.acceleration
                              )
  else
    --applying friction
    self.velocity.y = LUME.lerp(
                                self.velocity.y, 
                                0, 
                                self.friction
                              )

    self.velocity.x = LUME.lerp(
                                self.velocity.x, 
                                0, 
                                self.friction
                              )
  
  end

  self:collide(dt, true)
end

function ENTITY:topdown_2d_movement(dt)
  -- keyboard movement
  --classic up button movement going up left right and down with regards to player angle feels clunky
  --dx and dy are meant to be normalization vectors so when the character moves diagonally they don'time go faster from the x and y speed together
  local up = love.keyboard.isDown('up','w')
  local down = love.keyboard.isDown('down','s')
  local right = love.keyboard.isDown('right','d')
  local left = love.keyboard.isDown('left','a')

  
  



  if up then
    self.direction.y = -1
    
  elseif down then
    self.direction.y = 1
   
  else
    self.direction.y = 0
  end
  
  if left then
    self.direction.x = -1
    
  elseif right then
    self.direction.x = 1
    
  else
    self.direction.x = 0
  end

  --normalization without hump
  --local normalizer = math.sqrt(self.direction.x * self.direction.x + self.direction.y * self.direction.y)
  --self.direction.x = self.direction.x/normalizer 
  --self.direction.y = self.direction.y/normalizer
  --normalizeInplace method is spart of Hump.vectors class 
  self.direction:normalizeInplace()
  
  --if acceleration or friction is set to one it will immediately start and stop
  if self.direction.x ~= 0 then
    --applying acceleration
    
    self.velocity.x = LUME.lerp(
                                self.velocity.x, 
                                self.direction.x *  self.move_speed, 
                                self.acceleration
                              )
  else 
    --applying friction
    self.velocity.x = LUME.lerp(
                                self.velocity.x, 
                                0, 
                                self.friction
                              )
  end

  if self.direction.y ~= 0 then
    --applying acceleration
    
    self.velocity.y = LUME.lerp(
                                self.velocity.y, 
                                self.direction.y *  self.move_speed, 
                                self.acceleration
                              )
  else 
    --applying friction
    self.velocity.y = LUME.lerp(
                                self.velocity.y, 
                                0, 
                                self.friction
                              )
  end

  --self.velocity = self.direction *  self.move_speed
  
  self:collide(dt, true)
end

function ENTITY:platformer_2d_movement(dt)
  -- Video about making a better jump in Godot using 
  --    SUVAT, or physics kinematic equations
  -- https://www.youtube.com/watch?v=IOe1aGY6hXA
  -- which is based off of this GDC talke on Building a Better Jump
  -- https://www.youtube.com/watch?v=hG9SzQxaCm8
  local up = love.keyboard.isDown('up','w')
  local right = love.keyboard.isDown('right','d')
  local left = love.keyboard.isDown('left','a')
  --keyboard movement
  self.plaforming = true
  
  if left then
    self.direction.x = -1
   
  elseif right then
    self.direction.x = 1
    
  else
    self.direction.x = 0
  end
  
  
  
  --if acceleration or friction is set to 1 it will immediately start and stop
  if self.direction.x ~= 0 then
    -- applying acceleration
    self.velocity.x = LUME.lerp(
                                self.velocity.x, 
                                self.direction.x *  self.move_speed, 
                                self.acceleration
                              )
  else 
    -- applying friction
    self.velocity.x = LUME.lerp(
                                self.velocity.x, 
                                0, 
                                self.friction
                              )
  end

  --applying gravity
  self.velocity.y = self.velocity.y  + self:get_gravity() * dt
  if self.velocity.y > self.terminal_velocity  then
    self.velocity.y = self.terminal_velocity
  end

  ---jumping
  --a non-variable one would just be velocity=jump velocity and 

  if self.grounded then 
    if up then
      self.velocity.y = self.jump_velocity
      self.grounded = false
    end
  end 


    --[[
    if self.vy ~= tiny then
      self.is_grounded = false
    end]]--
    
    
    --if not love.keyboard.isDown('x') then
      --self.vy = tiny
    --end
    
    
    --variable jumping, not sure if it works anymore
    --if love.keyboard.isDown('x') 
   -- and self.vy < 0 
    --and self.jump_counter < self.jump_segments
    --then
        --self.jump_counter = self.jump_counter + 1 
        
          
        --local rest_of_jump = self.max_jump_height * dt --(self.jump_counter/self.jump_segments)
        --self.vy = self.min_jump_height + rest_of_jump
        --if rest_of_jump <= self.max_jump_height then
          --self.vy = tiny
          
        --end
    --else
      --self.jump_counter = self.jump_segments
    --end
  
  self:collide(dt, true)
end

function ENTITY:get_gravity()
  if self.velocity.y < 0.0 then
    return self.jump_gravity 
  else
    return self.fall_gravity
  end
end

function ENTITY:apply_gravity(dt)
  --print("vx: "..tostring(self.vx))
  
  if self.grounded == false then
    --self.y = self.y + self.vy --* dt
    self.velocity.y = self.velocity.y + self:get_gravity() --* dt
  end
  
end

function ENTITY:update_hitbox_position()
  
  self.hitbox[1] = self.position.x             
  self.hitbox[2] = self.position.y
  self.hitbox[3] = self.position.x                   
  self.hitbox[4] = self.position.y + self.dimension.y
  
  self.hitbox[5] = self.position.x + self.dimension.x 
  self.hitbox[6] = self.position.y + self.dimension.y
  self.hitbox[7] =  self.position.x + self.dimension.x 
  self.hitbox[8] = self.position.y

end

--without his function nothing that isn't tile-based moves
function ENTITY:collide(dt, is_tiled)
  --the actually collision code for the library used for the W
  self.last_y = self.position.y
  local x,y,vx,vy= self.position.x,self.position.y,self.velocity.x,self.velocity.y

  local futureX =  x + vx * dt
  local futureY =  y + vy * dt
  
  if is_tiled then
    --using bump
    local nextX,nextY,cols,len = World:move(self,futureX,futureY)
    for i = 1 , len do
      local col = cols[i]
      local kind = col.other.class
       if col.normal.y == -1  then
  
        self.grounded = true
        self.velocity.y = 0
      
      end

      if col.normal.y == 1  then
  
        self.velocity.y = 0
      
      end

      if col.normal.y ~= -1  then
  
        self.grounded = false

      end
      

    end
    self.position.x = nextX
    self.position.y = nextY
  else
    self.position.x = futureX
    self.position.y = futureY
  end

  
end

function ENTITY:add_in_world()

  World:add(self, self.position.x,self.position.y,self.dimension.x,self.dimension.y)

end

function ENTITY:delete_in_world()
  World:remove(self)
end

function ENTITY:remove_from_group(group,ind)

  table.remove(group,ind)
  
end

--one actually draws the other draws a box
function ENTITY:draw_line()
  love.graphics.line(self.line.x1,self.line.y1,self.line.x2,self.line.y2)
end

function ENTITY:draw()
  love.graphics.draw(self.img,self.quad,self.position.x,self.position.y)
end

function ENTITY:display(mode)
  --mode used to take the place of argument 1
  love.graphics.rectangle(mode,self.position.x,self.position.y,self.dimension.x,self.dimension.y)
end

