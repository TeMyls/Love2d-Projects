require "maps.testmap"
-- Global libraries
-- all are available by the link or in the lib folder

-- hump - Helper Utilities for a Multitude of Problems
-- General purpose library with various tools ranging from 
--    It contains a timer, vector, OOP, signals, camera, and gamestate libraries
-- https://github.com/vrld/hump
-- https://hump.readthedocs.io/en/latest/index.html
GAMESTATE = require "lib.hump.gamestate"
VECTOR2   = require "lib.hump.vector"
CAMERA    = require "lib.hump.camera"
TIMER    = require "lib.hump.timer"


-- A camera library for Love2D
-- github.com/kikito/gamera
GAMERA  = require "lib.gamera"


-- lume - Lua functions geared towards gamedev 
-- Another general purpose library 
--    Contains various useful functions geared towards GAME_SCENE development
--    lerp, round, clamp, sign, pingpong, angle, vector and far more
--[[
    --LUME tween easing OPTIONS added via "ease:(option_below)""
        linear 
        quadin quadout quadinout 
        cubicin cubicout cubicinout 
        quartin quartout quartinout 
        quintin quintout quintinout 
        expoin expoout expoinout 
        sinein sineout sineinout 
        circin circout circinout 
        backin backout backinout 
        elasticin elasticout elasticinout
]]
-- https://github.com/rxi/lume/
LUME    = require 'lib.lume'


-- flux - A fast, lightweight tweening library for Lua.
-- https://github.com/rxi/flux
FLUX    = require 'lib.flux'


-- suit - Immediate Mode GUI library for LÖVE 
--    great for debugging
-- https://github.com/vrld/suit
-- https://suit.readthedocs.io/en/latest/index.html
SUIT    = require 'lib.suit'


-- unused, but included libraries in the lib folder
--    anim8 - An animation library for LÖVE 
--    https://github.com/kikito/anim8
--    SYSL - Text rendering with tag support. 
--    https://github.com/sysl-dev/SYSL-Text/
--    json.lua - a lightweight JSON library for lua
--    https://github.com/rxi/json.lua
--    wave - A LÖVE sound manager with advanced audio parsing 
--    https://github.com/Ulydev/wave
-- libraries local to entity_2D
--    bump.lua - A Collision-detection library in primarily focused on
--        axis-aligned bounding box, or AABB collision
--        this is focused on rectangles, making it ideal for tile based games   
--    https://github.com/kikito/bump.lua
--    Jumper - Pathfinding Library for Lua
--    https://github.com/Yonaba/Jumper
--    classic - Class/Object Orientated Programming(OOP) Library for Lua
--    https://github.com/rxi/classic

-- various other libraries maintained by the Love2D community
-- github.com/love2d-community/awesome-love2d?tab=readme-ov-file#shaders

-- CAMERA setup
-- GAM = GAMERA.new(0,0,100,100)
CAMERA_ZOOM = 3
CAM =  CAMERA()
CAM:zoom(CAMERA_ZOOM)


--Global Constants
TILESIZE              = 16
SCREEN_WIDTH          = love.graphics.getWidth()
SCREEN_HEIGHT         = love.graphics.getHeight()
VIRTUAL_WIDTH         = SCREEN_WIDTH
VIRTUAL_HEIGHT        = SCREEN_HEIGHT
LEVEL                 = MAP_TILES
LEVEL_WIDTH           = #LEVEL[1]
LEVEL_HEIGHT          = #LEVEL
WORLD_LEVEL_WIDTH     = LEVEL_WIDTH * TILESIZE
WORLD_LEVEL_HEIGHT    = LEVEL_HEIGHT * TILESIZE
CIRCLE_ARENA          = {fill = "line", x = 0, y=0, r = 500}


--Global groups for objects
TILES       = {}
PROTAG      = {}
PROJECTILES = {}
ENEMIES     = {}
SPRITEBATCH = nil



--images
TILESET_PATH      = "assets/pc.png"
PLAYER_IMAGE_PATH = "assets/pc.png"

local r, g, b = love.math.colorFromBytes(172, 170, 189)
love.graphics.setBackgroundColor(r, g, b)
--makes pixels crisp
love.graphics.setDefaultFilter("nearest", "nearest")

--scenes
MENU_SCENE    = {}
PAUSE_SCENE   = {}
GAME_SCENE    = {}
HOW_SCENE     = {}
require "scene_menu"
require "scene_pause"
require "scene_game"
require "scene_how"



---------------------------------------------------------------------------------------------------------------
-- Actual Gameloop
---------------------------------------------------------------------------------------------------------------

function love.load(args)

  GAMESTATE.registerEvents()
  GAMESTATE.switch(MENU_SCENE)
  --GAMESTATE.switch(GAME_SCENE)
  --GAMESTATE.switch(PAUSE_SCENE)
end

-- love callback will still be invoked
function love.update(dt)
  
  -- no need for GAMESTATE.update(dt)

end

function love.draw()
  --SUIT:draw()
  --if GAMESTATE.current() == GAME_SCENE then
  
    GAMESTATE.draw()

  --actually draws the SUIT object instance itself
  GAME_UI:draw()
  --end
end

function love.keypressed(key)
  
end

function love.mousepressed(x, y, button, istouch)
  
end

function love.wheelmoved(x, y)
  
end

function love.resize(w, h)
  --Push:resize(w, h)
  local prev_width, prev_height = SCREEN_WIDTH, SCREEN_HEIGHT
  SCREEN_WIDTH, SCREEN_HEIGHT = w, h
  --overall scale change
  local old_width_scale  = (prev_width/VIRTUAL_WIDTH) * VIRTUAL_WIDTH
  local old_height_scale = (prev_height/VIRTUAL_HEIGHT) * VIRTUAL_HEIGHT

  local cur_width_scale   = (SCREEN_WIDTH/VIRTUAL_WIDTH) * VIRTUAL_WIDTH
  local cur_height_scale  = (SCREEN_HEIGHT/VIRTUAL_HEIGHT) * VIRTUAL_HEIGHT
  
  local width_inc   = (cur_width_scale - old_width_scale)/prev_width + 1
  local height_inc  = (cur_height_scale - old_height_scale)/prev_height + 1
  print(("Ratio X %f Ratio Y %f"):format(
                                    width_inc,
                                    height_inc
                                  ))
  CAMERA_ZOOM = CAMERA_ZOOM * ((width_inc + height_inc)/2)
  CAM:zoomTo(CAMERA_ZOOM)

end

