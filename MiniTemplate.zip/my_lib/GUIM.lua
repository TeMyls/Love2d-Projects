local GUIM = {}
GUIM.__index = GUIM

local _floor, _cos, _sin, _max, _abs, _sqrt, _min = math.floor, math.cos, math.sin, math.max, math.abs, math.sqrt, math.min
local tree = require "my_lib.n_ary_tree"
local collider = require "my_lib.collider"

--local button = require "button"
--local scale = require "scale"




function GUIM:new()
  
  local self = setmetatable({}, GUIM)
  self.collider = collider:new()
  self.tree = tree:new() 
  self.show_index = true
  self.show_widget = true
  self.show_text = true 


  -- for the node on top of the entire array, index 1, usually x1 = 0 , x2 = screen_width, y1 = 0 and y2 = screen_height 
  -- childern can be found through DFS, depth first search, or BFS Breadth first serach
  
  -- Sets of x1-y1-x2-y2 
  -- the panel area itself
  -- is overridden by width_pct or height_pct
  self.areas = {}
  -- internal anchor
  -- Sets of either "" ,C, N, NE, E, SE, S, SW, W, or NE:
      -- describes a x1-y1-x2-y2 is positioned inside a 
      -- default "" 
      -- designates the location of the panel in the sub space
  self.int_anchors = {}
  -- external anchor
  -- "", N, NE, NW, EN, E, ES, WN, W, WS, S, SE, SW, WNW, NEN, SES, WSW:
      -- default ""
      -- designates the location of the panel outside a space
  self.ext_anchors = {}
  -- Sets of "", X", "Y", or "Both"
      -- default: ""
      -- makes the panel take up more parts of it's parent area, horizontally, vertically or both
  self.fills = {}
  -- the color of the panel and the area it inhabits
  self.rgbs = {}

  -- width percentage of parent
  self.width_pcts = {}
  -- height percentage of parent
  self.height_pcts = {}

  -- percentage of the shortest side -be it height or width applies to both sides
  self.min_pcts = {}

  -- line width - an integer
  self.line_widths = {}
  -- line styles 
      -- smooth or rough
  self.line_styles = {}

  self.widgets = {}

  self.texts = {}
  self.rxs = {}
  self.rys = {}
  self.segments = {}
  --parent indexes
  self.parent_idxs = {}

  -- a table of 
  self.modes = {}

  
    

  return self
end

function GUIM:update(dt)

end


function GUIM:get_random_rgb()
  return { 
            r = love.math.random(), 
            g = love.math.random(), 
            b = love.math.random(),
            a = 1
          }
end

function GUIM:get_dimensions(parent_idx, idx)
  local child_area = self.areas[idx]
  local aw = _abs(child_area.x2 - child_area.x1)
  local ah = _abs(child_area.y2 - child_area.y1)
  
  local parent_area = self.areas[parent_idx]
  
  local uw = _abs(parent_area.x2 - parent_area.x1)
  local uh = _abs(parent_area.y2 - parent_area.y1)
  --print("child ",child_area.x1, child_area.y1, child_area.x2, child_area.y2, aw, ah)
  --print("parent ",parent_area.x1, parent_area.y1, parent_area.x2, parent_area.y2, uw, uh)
  return aw, ah, uw, uh 
end

function GUIM:get_iAnchor(parent_idx, idx)
  local aw, ah, uw, uh = self:get_dimensions(parent_idx, idx)

  local child_area = self.areas[idx]
  local parent_area = self.areas[parent_idx]
  
  local top_x = parent_area.x1
  local top_y = parent_area.y1
  
  local mid_x = parent_area.x1 + _abs(uw/2 - aw/2)
  local mid_y = parent_area.y1 + _abs(uh/2 - ah/2)
  
  local end_x = parent_area.x2 - aw
  local end_y = parent_area.y2 - ah
  
  return {
    ["N"]  = {x = mid_x, y = top_y},
    ["NE"] = {x = end_x, y = top_y},
    ["NW"] = {x = top_x, y = top_y},
    ["C"]  = {x = mid_x, y = mid_y},
    ["E"]  = {x = end_x, y = mid_y},
    ["W"]  = {x = top_x, y = mid_y},
    ["S"]  = {x = mid_x, y = end_y},
    ["SE"] = {x = end_x, y = end_y},
    ["SW"] = {x = top_x, y = end_y}
  }
end

function GUIM:get_eAnchor(parent_idx, idx)
  
  local aw, ah, uw, uh = self:get_dimensions(parent_idx, idx)
  
  local child_area = self.areas[idx]
  local parent_area = self.areas[parent_idx]
  
  local top_x = parent_area.x1
  local top_y = parent_area.y1
  
  local mid_x = parent_area.x1 + _abs(uw/2 - aw/2)
  local mid_y = parent_area.y1 + _abs(uh/2 - ah/2)
  
  local end_x = parent_area.x2 - aw
  local end_y = parent_area.y2 - ah
  
  return {
    
    ["N"]  = {x = mid_x, y = top_y - ah},
    ["NE"] = {x = end_x, y = top_y - ah},
    ["NW"] = {x = top_x, y = top_y - ah},
    
    ["EN"] = {x = end_x + aw, y = top_y},
    ["E"]  = {x = end_x + aw, y = mid_y},
    ["ES"] = {x = end_x + aw, y = end_y},
    
    ["WN"] = {x = top_x - aw, y = top_y},
    ["W"]  = {x = top_x - aw, y = mid_y},
    ["WS"] = {x = top_x - aw, y = end_y},
    
    ["S"]  = {x = mid_x, y = end_y + ah},
    ["SE"] = {x = end_x, y = end_y + ah},
    ["SW"] = {x = top_x, y = end_y + ah},
    
    ["WNW"] = {x = top_x - aw, y = top_y - ah},
    ["NEN"] = {x = end_x + aw, y = top_y - ah},
    ["SES"] = {x = end_x + aw, y = end_y + ah},
    ["WSW"] = {x = top_x - aw, y = end_y + ah}
			
  }
end

function GUIM:apply_area(parent_idx, idx)
  if parent_idx ~= -1 then

    local aw, ah, uw, uh = self:get_dimensions(parent_idx, idx)
    local width_pct = self.width_pcts[idx]/100
    local height_pct = self.height_pcts[idx]/100
    local min_pct = self.min_pcts[idx]/100

    if self.min_pcts[idx] ~= -1 then
      local mn = _min(uw, uh)
      self.areas[idx] = {
                            x1 = 0, y1 = 0,
                            x2 = mn * min_pct, y2 = mn * min_pct
      }
    else
      if self.width_pcts[idx] ~= -1 then
        
        self.areas[idx] = {
                            x1 = 0, y1 = 0,
                            x2 = uw * width_pct, y2 = ah
        }
        
      end
      
      aw, ah, uw, uh = self:get_dimensions(parent_idx, idx)
      
      if self.height_pcts[idx] ~= -1 then
        
        self.areas[idx] = {
                            x1 = 0, y1 = 0,
                            x2 = aw, y2 = uh * height_pct
        }
        
      end
    end
    
    --print(width_pct, height_pct)
    
    if self.int_anchors[idx] ~= "" then 
      
      aw, ah, uw, uh = self:get_dimensions(parent_idx, idx)
      local ia = self.int_anchors[idx]
      local directions = self:get_iAnchor(parent_idx, idx)
      local coords = directions[ia]
      self.areas[idx] = {
        x1 = coords.x,      y1 = coords.y,
        x2 = coords.x + aw, y2 = coords.y + ah
      }
          
      if self.fills[idx] == "Y" then
            
        if self.int_anchors[idx] == "W" or 
          self.int_anchors[idx] == "SW" or 
          self.int_anchors[idx] == "NW" then
              
            self.areas[idx] = {
                
              x1 = directions["NW"].x,      y1 = directions["NW"].y,
              x2 = directions["SW"].x + aw, y2 = directions["SW"].y + ah
                
            }
              
        elseif self.int_anchors[idx] == "E" or 
          self.int_anchors[idx] == "SE" or 
          self.int_anchors[idx] == "NE" then
              
          self.areas[idx] = {
                  
            x1 = directions["NE"].x,      y1 = directions["NE"].y,
            x2 = directions["SE"].x + aw, y2 = directions["SE"].y + ah
                
            }
              
        end
            
      elseif self.fills[idx] == "X" then
            
        if self.int_anchors[idx] == "N" or 
          self.int_anchors[idx] == "NE" or 
          self.int_anchors[idx] == "NW" then
              
            self.areas[idx] = {
                  
              x1 = directions["NW"].x,      y1 = directions["NW"].y,
              x2 = directions["NE"].x + aw, y2 = directions["NE"].y + ah
                
            }
              
        elseif self.int_anchors[idx] == "S" or 
          self.int_anchors[idx] == "SE" or 
          self.int_anchors[idx] == "SW" then
              
            self.areas[idx] = {
                  
              x1 = directions["SW"].x,      y1 = directions["SW"].y,
              x2 = directions["SE"].x + aw, y2 = directions["SE"].y + ah
                
            }
              
        end
            
      elseif self.fills[idx] == "Both" then
            
            self.areas[idx] = {
                  
                x1 = directions["NW"].x,      y1 = directions["NW"].y,
                x2 = directions["SW"].x + aw, y2 = directions["SW"].y + ah
                
              }
            
      end
    end
      
      
      
      
    if self.ext_anchors[idx] ~= "" then
      aw, ah, uw, uh = self:get_dimensions(parent_idx, idx)

      local directions = self:get_eAnchor(parent_idx, idx)
      
      local ie = self.ext_anchors[idx]
      local coords = directions[ie]
          self.areas[idx] = {
            x1 = coords.x,      y1 = coords.y,
            x2 = coords.x + aw, y2 = coords.y + ah
          }
    end
  end
end

function GUIM:add_area(kwargs)
  
  local idx = #self.areas + 1

  local parent_idx = kwargs.parent_idx or -1
  self.tree:add_index(idx, parent_idx)
  table.insert(self.parent_idxs, parent_idx)
  

  local area = kwargs.area or {x1 = -1, y1 = -1, x2 = -1, y2 = -1}
  table.insert(self.areas, area)
  

  local width_pct = kwargs.width_pct or -1
  table.insert(self.width_pcts, width_pct)
  

  local height_pct = kwargs.height_pct or -1
  table.insert(self.height_pcts, height_pct)

  local min_pct = kwargs.min_pct or -1
  table.insert(self.min_pcts, min_pct)
  
  
  local fill = kwargs.fill or ""
  table.insert(self.fills, fill)


  local ext_anchor = kwargs.ext_anchor or ""
  table.insert(self.ext_anchors, ext_anchor)


  local int_anchor = kwargs.int_anchor or ""
  table.insert(self.int_anchors, int_anchor)

  
  local rgb = kwargs.rgb or {r = -1, g = -1, b = -1, a = 1}
  table.insert(self.rgbs, rgb)


  local rx = kwargs.rx or 0
  table.insert(self.rxs, rx)
  
  
  local ry = kwargs.ry or 0
  table.insert(self.rys, ry)
  

  local segments = kwargs.segments or 0
  table.insert(self.segments, segments)
  
 
  local mode = kwargs.mode or ""
  table.insert(self.modes, mode)


  local line_width = kwargs.line_width or 1
  table.insert(self.line_widths, line_width)


  local line_style = kwargs.line_style or "smooth"
  table.insert(self.line_styles, line_style)

  local widget = kwargs.widget or ""
  table.insert(self.widgets, widget)


  self:apply_area(parent_idx, idx)

  --print("Added Index: ",idx)
  return idx
end

function GUIM:render_areas()
  --if #self.tree.edges > 0 then
    --print("yea", #self.areas)
    local root_node = 1
    local deque = self.tree:traverse(root_node, false)

    while #deque > 0 do
      
      local item = table.remove(deque, 1)
      local has_color = self.rgbs[item].r ~= -1 and self.rgbs[item].g ~= -1 and self.rgbs[item].b
      
      
      
      if has_color then
        love.graphics.setColor(self.rgbs[item].r, self.rgbs[item].g, self.rgbs[item].b, self.rgbs[item].a)
      end


      if self.modes[item] ~= "" and (self.modes[item] == "fill" or  self.modes[item] == "line") then
        if self.modes[item] == "line" then
          love.graphics.setLineWidth(self.line_widths[item])
          love.graphics.setLineStyle(self.line_styles[item])
        end

        love.graphics.rectangle(
        
                                self.modes[item], 
                                self.areas[item].x1, 
                                self.areas[item].y1, 
                                math.abs(self.areas[item].x2 - self.areas[item].x1),
                                math.abs(self.areas[item].y2 - self.areas[item].y1),
                                self.rxs[item],
                                self.rys[item],
                                self.segments[item]
                                
                            )
                            
        
        if self.modes[item] == "line" then
          love.graphics.setLineWidth(1)
          love.graphics.setLineStyle("smooth")
        end

        

      end
      
      if self.show_index and has_color then

        love.graphics.setColor(_abs(1 - self.rgbs[item].r), _abs(1 - self.rgbs[item].g), _abs(1 - self.rgbs[item].b), 1)
        love.graphics.print(tostring(item), self.areas[item].x1 + 15, self.areas[item].y1 + 15) 
        
      end

      if has_color then 
        love.graphics.setColor(1, 1, 1) 
      end

      if self.show_widget then
        if self.widgets[item] ~= "" then
          self.widgets[item].area = self.areas[item]
          self.widgets[item]:draw()
        end
      end


      
      
      
    end
    

end

function GUIM:update_areas()

  local root_node = 1
  local deque = self.tree:traverse(root_node, true)

  while #deque > 0 do
    local idx = table.remove(deque, #deque)
    --print(("Parent Idx: %d Idx %d"):format(self.parent_idxs[value] or -1, value))
    --
    
    local parent_idx = self.parent_idxs[idx]
    --print("Parent Idx", parent_idx, "Idx: ", idx)
    
    self:apply_area(parent_idx, idx)
    
  end
  
end

function GUIM:update(dt)
    
end



function GUIM:draw()
  self:update_areas()
  self:render_areas()
end

return GUIM