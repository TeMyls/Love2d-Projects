local button = {}
button.__index = button
local _floor, _cos, _sin, _max, _abs, _sqrt, _min = math.floor, math.cos, math.sin, math.max, math.abs, math.sqrt, math.min
local collider = require "my_lib.collider"
local GUIM = require "my_lib.GUIM" 


-- this button serves as a button, text input field, a text label, and image holder, possibly a rabiobutton or checkbutton as a subclass, and a 

function button:new(kwargs)--(x1, y1, x2, y2, img)

    --button = {}

    local self = setmetatable({}, button)
    self.area = kwargs.area or {x1 = -1, y1 = -1, x2 = -1, y2 = -1}
    self.collider = collider:new()
    -- line width - an integer
    self.line_width = kwargs.line_width or 1
    -- line styles 
        -- smooth or rough
    self.line_style = kwargs.line_style or "smooth"
    -- font size
    self.font_size = kwargs.font_size or -1
    -- font file path
    self.font_path = kwargs.font_path or ""
    -- default font
    self.default_font = love.graphics.getFont()
    -- the font to be set by love.graphics.setFont(font_path, font_size)
    if self.font_path ~= "" then
        if self.font_size ~= -1 then
            self.font_type = love.graphics.newFont(self.font_path, self.font_size) 
        else
            self.font_type = love.graphics.newFont(self.font_path)
        end
        
    else
        -- love's defualt font
        if self.font_size ~= -1 then
            self.font_type = love.graphics.newFont(self.font_size) 
        else
            self.font_type = love.graphics.getFont()
        end
      
        
    end

    self.font_relative = kwargs.font_relative or false
    self.name = kwargs.name or "button"
    self.text = kwargs.text or ""
    self.display_text = self.text
    self.text_anchor = kwargs.text_anchor or "C"

    self.img_anchor = kwargs.img_anchor or "C"

    self.rx = kwargs.rx or 0
    self.ry = kwargs.ry or 0
    self.segments = kwargs.segments or 0
    --self.pidxs = {}
    -- scissor cuts the entire area where text is located, meaning that text on the edge of an area will be cut and not be rendered
    self.use_scissor = kwargs.use_scissor or false
    -- clip text prevents text from outside the area from being rendered entirely, showing only a portion of text which can fit in the area
    self.clip_text = kwargs.clip_text or false

    

    self.word_wrap  = kwargs.word_wrap or false
    self.draw_image = kwargs.draw_image or false
    self.draw_polygon = kwargs.draw_polygon or false
    self.mouse_down = false
    self.text_pct = 0


    self.sub_gui = ""
    self.use_sub_gui = kwargs.use_sub_gui or false
    if self.use_sub_gui then
        
        self.sub_gui = GUIM:new()
        local first_area = self.sub_gui:add_area(
            {
            area = {
                x1 = 0,
                y1 = 0,
                x2 = SCREEN_WIDTH,
                y2 = SCREEN_HEIGHT
            },
            fill = "",
            mode = "fill",
            ext_anchor = "",
            int_anchor = "N",
            parent_idx = nil,
            --rgb = { }
            
            }
        )

        
        print("passed", first_area)
    end
    
    self.vertical_pct = 0
    self.horizontal_pct = 0
    self.sub_vertical = kwargs.sub_vertical or false
    self.sub_horizontal = kwargs.sub_horizontal or false

    
    self.text_scroll = false
    self.name = "button"
    
    self.mode =  kwargs.mode or ""

    self.rgb = kwargs.rgb or {r = -1, g = -1, b = -1, a = 1}
    self.text_rgb = kwargs.text_rgb or {r = -1, g = -1, b = -1, a = 1}

    self.img = kwargs.img or -1

    self.quad = nil
    if self.img ~= -1 then
        self.img = love.graphics.newImage(self.img)
        --self.quad = love.graphics.newQuad(self.quad_x, self.quad_y, self.dimension.x,self.dimension.y,self.img)
    end


    --setmetatable( button , self)
  return self
end

function button:clamp(value, lower, upper)
  return _max(lower , _min(value, upper))
end

function button:distance_to(x1, y1, x2, y2)
  return _sqrt((x2 - x1) ^ 2 + (y2 - y1) ^ 2)
end

function button:lerp(a, b, pct)
  return a + (b - a) * pct
end

function button:angle_to(x1, y1, x2, y2)
  return math.atan( y2 - y1, x2 - x1)
end

function button:format_text(str)
    local font = love.graphics.getFont()
    --gets the dimensions of the font in the current string, adjusted for it's size and style, including newlines
    local fw = font:getWidth(str)
    
    local fh = font:getHeight()
    

    local uw = _abs(self.area.x2 - self.area.x1)
    local uh = _abs(self.area.y2 - self.area.y1)

    local rw = fw/uw
    local rh = fh/uh
    --print(rw, rh)
    if rw > 1 then
        local new_str = ""
        local i = 1
        local j = 0
        --print(fw, string.len(str))
        
        -- width in pixels of an individual character
        local char_width = fw/string.len(str)
        local char_per_row = _floor(uw/char_width)
        local char_rows_vis = _floor(uh/fh)
        
        
        --print(char_rows_vis)
        --print(char_width, char_per_row, char_rows_vis)
        --for i = 1, string.len(str) do
        while i < string.len(str) do
            --print("asjdas")
            -- stops text from exiting area
            if j == char_rows_vis and 
            self.clip_text then
                print("amdksd", i)
                break
            end

            -- wraps text around area once the char per line limit is reached
            if i % char_per_row == 0 then
                new_str = new_str.."\n"
                j  = j + 1
            end
            
            --prevents single letter overhand
            if j ~= char_rows_vis then
               new_str = new_str..string.sub(str, i, i)
            end

            i = i + 1
        end

        
        --print(new_str)
        return new_str
    end
    return str
end

function button:get_image_dimensions()

    local img = self.img
    local aw = img:getWidth()
    local ah = img:getHeight()

    local uw = _abs(self.area.x2 - self.area.x1)
    local uh = _abs(self.area.y2 - self.area.y1)
    return aw, ah, uw, uh

end

function button:get_text_dimensions()
    local font = love.graphics.getFont()

    local aw = font:getWidth(self.display_text)
    local ah = font:getHeight()

    -- where word wrap was 

    local uw = _abs(self.area.x2 - self.area.x1)
    local uh = _abs(self.area.y2 - self.area.y1)
    return aw, ah, uw, uh

end

function button:get_imAnchor()

    local aw, ah, uw, uh = self:get_image_dimensions()

    local parent_area = self.area
    
    local top_x = parent_area.x1
    local top_y = parent_area.y1
    
    local mid_x = parent_area.x1 + _abs(uw/2 - aw/2)
    local mid_y = parent_area.y1 + _abs(uh/2 - ah/2)
    
    local end_x = parent_area.x2 - aw
    local end_y = parent_area.y2 - ah
    
    return {
        ["N"]  = {x = mid_x, y = top_y},
        ["NE"] = {x = end_x, y = top_y},
        ["NW"] = {x = top_x, y = top_y},
        ["C"]  = {x = mid_x, y = mid_y},
        ["E"]  = {x = end_x, y = mid_y},
        ["W"]  = {x = top_x, y = mid_y},
        ["S"]  = {x = mid_x, y = end_y},
        ["SE"] = {x = end_x, y = end_y},
        ["SW"] = {x = top_x, y = end_y}
    }

end

function button:get_tAnchor()

    local aw, ah, uw, uh = self:get_text_dimensions()

    local parent_area = self.area
    
    local top_x = parent_area.x1
    local top_y = parent_area.y1
    
    local mid_x = parent_area.x1 + _abs(uw/2 - aw/2)
    local mid_y = parent_area.y1 + _abs(uh/2 - ah/2)
    
    local end_x = parent_area.x2 - aw
    local end_y = parent_area.y2 - ah
    
    return {
        ["N"]  = {x = mid_x, y = top_y},
        ["NE"] = {x = end_x, y = top_y},
        ["NW"] = {x = top_x, y = top_y},
        ["C"]  = {x = mid_x, y = mid_y},
        ["E"]  = {x = end_x, y = mid_y},
        ["W"]  = {x = top_x, y = mid_y},
        ["S"]  = {x = mid_x, y = end_y},
        ["SE"] = {x = end_x, y = end_y},
        ["SW"] = {x = top_x, y = end_y}
    }

end

function button:chop_start()
    if self.use_scissor then
        love.graphics.setScissor(
                                self.area.x1, 
                                self.area.y1, 
                                _abs(self.area.x2 - self.area.x1),
                                _abs(self.area.y2 - self.area.y1)
        )
        
        
        
    end
end

function button:chop_end()
    if self.use_scissor then
        love.graphics.setScissor( )
    end
end

function button:_is_hovering_over(x, y)
  --print(self.area.x1, self.area.y1, self.area.x2, self.area.y2, x, y)
  --[[  print(     
        self.area.x1, 
        self.area.y1, 
        self.area.x1,
        self.area.y2,
        self.area.x2,
        self.area.y2,
        
        self.area.x2,
        self.area.y1
    )
    ]]
    
  --[[
  if self.collider:polygon_point(
    {           
        self.area.x1, 
        self.area.y1, 
        self.area.x1,
        self.area.y2,
        self.area.x2,
        self.area.y2,
        
        self.area.x2,
        self.area.y1,
    },
    x, y--, 5
  ) then
    ]]

    
  if self.collider:circle_rectangle(
                                      x, y, 5,
                                      self.area.x1, self.area.y1, 
                                      _abs(self.area.x2 - self.area.x1), _abs(self.area.y2 - self.area.y1)
                                    ) then


   return true
  end
  return false

end

function button:_is_mouse_pressed(x, y, mouse_int)
    --to be placed in love.mousepressed
  -- key is tapped
  if self:_is_hovering_over(x, y) then
    return true
  end

  
end

function button:_is_mouse_down(x, y, mouse_int)
  -- key is continously held
  if self:_is_hovering_over(x, y) then
 
    if love.mouse.isDown(mouse_int) then
        return true
    end
  end
  return false
  
end

function button:_is_key_pressed(x, y, key)
    --to be placed in love.keypressed(key)
  -- key is tapped
  if self:_is_hovering_over(x, y) then
    return true
  end

  
end

function button:_is_key_down(x, y, key)
  -- key is continously held
  if self:_is_hovering_over(x, y) then
    if love.keyboard.isDown(key) then
        return true
    end
  end
  return false
  
end

function button:_add_area_to_sub_gui(kwargs)
    if self.use_sub_gui then
        --print("asuaudsd", #self.sub_gui.areas)
        -- returns the index in the sub_gui
        return self.sub_gui:add_area(
            kwargs
        )
    end
end

function button:_draw_image()
    if self.draw_image then
        if self.img ~= -1 then
            --local im_width = self.img:getWidth()
            --local im_height = self.img:getHeight()
            --local btn_width = _abs(self.area.x2 - self.area.x1)
            --local btn_height = _abs(self.area.y2 - self.area.y1)
            local im_width, im_height, btn_width, btn_height = self:get_image_dimensions()
            local rw = btn_width/im_width
            local rh = btn_height/im_height
            local rm = _min(rw, rh)
            local im_pos = self:get_imAnchor()[self.img_anchor]
            --love.graphics.draw(self.img,self.quad,self.position.x,self.position.y, 0)
            love.graphics.draw(self.img, im_pos.x,im_pos.y, 0, rm, rm)

        end
    end
end

function button:_draw_polygon()
    if self.draw_polygon then
        if self.mode ~= "" then
            local has_color = self.rgb.r ~= -1 and self.rgb.g ~= -1 and self.rgb.b ~= -1
      
            if self.mode == "line" then
                love.graphics.setLineWidth(self.line_width)
                love.graphics.setLineStyle(self.line_style)
            end
      
            if has_color then
                love.graphics.setColor(self.rgb.r, self.rgb.g, self.rgb.b, self.rgb.a)
            end

            
            love.graphics.rectangle(
            
                                    self.mode, 
                                    self.area.x1, 
                                    self.area.y1, 
                                    _abs(self.area.x2 - self.area.x1),
                                    _abs(self.area.y2 - self.area.y1),
                                    self.rx,
                                    self.ry,
                                    self.segments
                                    
                                )
            

            --[[
            love.graphics.polygon(
                self.mode, 
                self.area.x1, 
                self.area.y1, 
                self.area.x2,
                self.area.y1,
                self.area.x2,
                self.area.y2,
                self.area.x1,
                self.area.y2
            
            

            )
            ]]

            if has_color then
                love.graphics.setColor(1, 1, 1, 1) 
            end
            if self.mode == "line" then
                love.graphics.setLineWidth(1)
                love.graphics.setLineStyle("smooth")
            end
            

        end

    end
end

function button:_draw_text()
    if self.text ~= "" then
        self:chop_start()

        
        local has_color = self.text_rgb.r ~= -1 and self.text_rgb.g ~= -1 and self.text_rgb.b ~= -1

        if has_color then
            love.graphics.setColor(self.text_rgb.r, self.text_rgb.g, self.text_rgb.b, self.text_rgb.a)
        end
        
        
        
        
        
        
        

        love.graphics.setFont(self.font_type)


        local font = love.graphics.getFont()
        --gets the dimensions of the font in the current string, adjusted for it's size and style, including newlines
        local fw = font:getWidth(self.text)
        local fh = font:getHeight()
        

        local uw = _abs(self.area.x2 - self.area.x1)
        local uh = _abs(self.area.y2 - self.area.y1)

        -- is the font width or height greater than the area
        local rw = fw/uw
        local rh = fh/uh

        -- width in pixels of an individual character
        local char_width = fw/string.len(self.text)
        local char_per_row = _floor(uw/char_width)
        local char_rows_vis = _floor(uh/fh)
        local char_rows_total = _floor(string.len(self.text)/char_per_row)
        local new_str = ""
        local text_percentage = (self.text_pct/100)
        local text_len = string.len(self.text)
        local new_lines = { 1 }

        --print(char_rows_total, char_per_row)

        if self.word_wrap then
        
            --local new_text = self:format_text(self.text)
            

            --print(self.clip_text, self.use_scissor, self.name)
            --print(rw, rh)
            if rw > 1 then
                
                local i = 1 
                local row = 0

                local line_len = 0
                local current_word = ""
            

                --while string.sub(self.text, w, w) ~= " " do
                  --  current_word = current_word..string.sub(self.text, w, w)
                    --w = w + 1
                --end
                
                if self.clip_text then
                  
                  --i = i + _floor(text_percentage * char_rows_total) * char_per_row 
                  
                end

                --print(fw, string.len(str))
                while i <= text_len do

                    -- skipping leading spaces
                    while i <= text_len and string.sub(self.text, i, i) == " " do
                        i = i + 1
                    end

                    if i > text_len then
                        break
                    end

                    -- find end of current word
                    local word_end = i

                    while word_end <= text_len and string.sub(self.text, word_end, word_end) ~= " " do
                        word_end = word_end + 1
                    end

                    local word = string.sub(self.text, i, word_end - 1)
                    local word_len = #word

                    -- wrap before placing the word
                    if line_len > 0 and line_len + 1 + word_len > char_per_row then

                        new_str = new_str .. "\n"
                        row = row + 1
                        line_len = 0
                       
                    end

                    -- add space if not first word on line
                    if line_len > 0 then
                        new_str = new_str .. " "
                        line_len = line_len + 1
                        
                    end

                    -- add the word to the new string
                    new_str = new_str .. word
                    line_len = line_len + word_len

                    -- move to next word that was incremented 
                    i = word_end
                end
             
                char_rows_total = row 
                
                --print(new_str)
                
            else
                new_str = self.text
            end
            --local font = love.graphics.getFont()
            --aw = font:getWidth(new_text)
            --ah = font:getHeight()
            --self.display_text = new_text
            
            -- the reason this newline is added is to make sure the last of the the text shows

            self.display_text = new_str
            

        else
            
            --local font = love.graphics.getFont()
            --aw = font:getWidth(self.text)
            --ah = font:getHeight()
            self.display_text = self.text

        end

        -- for scrolling text use an text_anchor of "NW"
        local text_pos = self:get_tAnchor()[self.text_anchor]

        --if self.use_scissor and self.word_wrap and not self.clip_text then
        if self.word_wrap then

   
            if self.use_scissor then
                local text_offset = char_rows_total * fh * text_percentage
                --local new_text = self:format_text(self.text)
                --print(char_rows_total, text_offset, uh, char_rows_vis * fh)
                love.graphics.print(self.display_text, text_pos.x, text_pos.y - text_offset)
            elseif self.clip_text then
                local text_offset = _floor(text_percentage * char_rows_total) * fh
                
                love.graphics.setScissor(
                                    self.area.x1, 
                                    self.area.y1, 
                                    _abs(self.area.x2 - self.area.x1),
                                    char_rows_vis * fh
                )
                
                love.graphics.print(self.display_text, text_pos.x, text_pos.y - text_offset)
                love.graphics.setScissor( )
                
            end
        else
            love.graphics.print(self.display_text, text_pos.x, text_pos.y)
        end
        
        love.graphics.setFont(self.default_font)

        if has_color then
            love.graphics.setColor(1, 1, 1, 1) 
        end

        self:chop_end()
    end
end

function button:_draw_sub_gui()
    if self.use_sub_gui then
        self:chop_start()
        --print("yep areas", #self.sub_gui.areas)
        if #self.sub_gui.areas > 1 then
            
            -- the first area in the sub gui is the button's dimensions, 
            -- the second area is the true area it covers and should have a height_pct above 100 and an anchoring of "NW"
            self.sub_gui.areas[1] = {
                                        x1 = self.area.x1, 
                                        y1 = self.area.y1, 
                                        x2 = self.area.x2, 
                                        y2 = self.area.y2
                                    }

         
            local h_percentage = (self.horizontal_pct/100)
            local v_percentage = (self.vertical_pct/100)
            --print("asad", self.sub_pct)
            local second_height = self.sub_gui.areas[2].y2 - self.sub_gui.areas[2].y1 - (self.area.y2 - self.area.y1)
            local second_width =  self.sub_gui.areas[2].x2 - self.sub_gui.areas[2].x1 - (self.area.x2 - self.area.x1)
            if self.sub_horizontal then

                local sub_second_offset = second_width * h_percentage
                self.sub_gui.areas[1].x1 = self.sub_gui.areas[1].x1 - sub_second_offset
                self.sub_gui.areas[1].x2 = self.sub_gui.areas[1].x2 - sub_second_offset
                
            end
            if self.sub_vertical then
                
                local sub_second_offset = second_height * v_percentage
                self.sub_gui.areas[1].y1 = self.sub_gui.areas[1].y1 - sub_second_offset
                self.sub_gui.areas[1].y2 = self.sub_gui.areas[1].y2 - sub_second_offset
                
            end
            self.sub_gui:draw()
            

            
        end
        self:chop_end()
    end
end

function button:update(dt)

end



function button:draw()
    
    self:_draw_image()
    
    self:_draw_polygon()
    
    self:_draw_text()

    self:_draw_sub_gui()
    
end



return button