require "entity_2D"

Widget = ENTITY:extend()

function Widget:new(position_table,dimension_table,hp,tile_image_path,quad_x,quad_y,in_world,group_table)
  Widget.super.new(self,
    position_table,
    dimension_table,
    hp,
    tile_image_path,
    quad_x,
    quad_y,
    in_world,
    group_table
  )
  self.row = 0
  self.col = 0
  self.number = -3
  self.breakable = true
  
  -- the x and y coordinates are to be multipled by the TILESIZE
  -- meant for the Minesweeper.png file
  self.number_to_quad = {
    -- Boom
    [-2]= {x = 12, y = 0},
    -- Bomb
    [-1]= {x = 11, y = 0},
    -- Blank/Safe Cell
    [0] = {x = 10, y = 0},
    -- Normal cells 1 - 8
    [1] = {x = 1, y = 0},
    [2] = {x = 2, y = 0},
    [3] = {x = 3, y = 0},
    [4] = {x = 4, y = 0},
    [5] = {x = 5, y = 0},
    [6] = {x = 6, y = 0},
    [7] = {x = 7, y = 0},
    [8] = {x = 8, y = 0},
    -- hidden cell question mark
    [9] = {x = 14, y = 0},
    -- flag
    [10] ={x = 13, y = 0},
    -- options
    [101]={x = 15, y = 0},
    -- restart
    [102]={x = 16, y = 0},
    -- back
    [103]={x = 17, y = 0},
    -- plus
    [104]={x = 18, y = 0},
    -- minus
    [105]={x = 19, y = 0}
  }
  
  self.frame_size = TILESIZE
  self.scale = VECTOR2(1, 1)
  self.angle = {radians = 0}
  self.rgb = {r = 0, g = 0, b = 0}

  self.font_size = 10
  self.font_path = nil
  self.font = nil
  

  self.hovered = false
  self.og_hover_seconds = 1.2
  self.hover_seconds = 1.2
  self.hover_tally = 0
  self.hover_data = {
    [0] = {time = 0.15, og_time = 0.15, position = nil, scale = VECTOR2(1.10, 1.10), angle = {radians = self.angle_convert:degrees_to_radians(0)}, rgb = nil},
    [1] = {time = 0.15, og_time = 0.15, position = nil, scale = VECTOR2(1.15, 1.05), angle = {radians = self.angle_convert:degrees_to_radians(2)}, rgb = nil},
    [2] = {time = 0.15, og_time = 0.15, position = nil, scale = VECTOR2(1.10, 1.10), angle = {radians = self.angle_convert:degrees_to_radians(0)}, rgb = nil},
    [3] = {time = 0.15, og_time = 0.15, position = nil, scale = VECTOR2(1.05, 1.15), angle = {radians = self.angle_convert:degrees_to_radians(-2)}, rgb = nil}
    
  }


  self.revealing = false
  self.og_reveal_seconds = 0.6
  self.reveal_seconds = self.og_reveal_seconds
  self.reveal_tally = 0
  self.reveal_data = {
    [0] = {time = 0.08, og_time = 0.08, position = nil, scale = VECTOR2(1.00, 1.00), angle = {radians = self.angle_convert:degrees_to_radians(0)}, rgb = nil},
    [1] = {time = 0.08, og_time = 0.08, position = nil, scale = VECTOR2(0.95, 0.90), angle = {radians = self.angle_convert:degrees_to_radians(5)}, rgb = nil},
    [2] = {time = 0.07, og_time = 0.07, position = nil, scale = VECTOR2(1.10, 1.20), angle = {radians = self.angle_convert:degrees_to_radians(-3)}, rgb = nil},
    [3] = {time = 0.05, og_time = 0.05, position = nil, scale = VECTOR2(1.05, 1.00), angle = {radians = self.angle_convert:degrees_to_radians(0)}, rgb = nil}
  }


  -- this is initialized outside the function body
  self.spawning = false
  self.og_spawn_seconds = 0.7
  self.spawn_seconds = self.og_spawn_seconds
  self.spawn_tally = 0
  self.spawn_data = {
    [0] = {time = nil, og_time = nil, position = nil, scale = nil, angle = nil , rgb = nil},
  }

  self.changing_color = false
  self.text = nil
  self.text_tally = 0
  self.og_text_seconds = 0.3
  self.text_seconds = self.og_text_seconds 
  self.text_offset = VECTOR2.zero
  
  self.text_data = {
    [0] = {time = nil, og_time = nil, position = nil, scale = nil, angle = nil , rgb = {r = 0, g = 0, b = 0}},
  }

  self.coloring = false
  self.og_color_seconds = 0.6
  self.color_seconds = self.og_color_seconds
  self.color_tally = 0
  self.color_data = {
    [0] = {time = 0.08, og_time = 0.08, position = nil, scale = VECTOR2(1.00, 1.00), angle = {radians = self.angle_convert:degrees_to_radians(0)}, rgb = nil},
    [1] = {time = 0.08, og_time = 0.08, position = nil, scale = VECTOR2(0.95, 0.90), angle = {radians = self.angle_convert:degrees_to_radians(5)}, rgb = nil},
    [2] = {time = 0.07, og_time = 0.07, position = nil, scale = VECTOR2(1.10, 1.20), angle = {radians = self.angle_convert:degrees_to_radians(-3)}, rgb = nil},
    [3] = {time = 0.05, og_time = 0.05, position = nil, scale = VECTOR2(1.05, 1.00), angle = {radians = self.angle_convert:degrees_to_radians(0)}, rgb = nil}
  }

  self.flagged = false 
  self.flag_quad = nil
  self.flag_img = love.graphics.newImage(tile_image_path)
  self.flag_quad = love.graphics.newQuad(
                                      self.number_to_quad[10].x * self.frame_size, 
                                      self.number_to_quad[10].y * self.frame_size, 
                                      self.dimension.x, 
                                      self.dimension.y, 
                                      self.flag_img
                                    )



  self.play_position = VECTOR2.zero
  self.hidden = true
  self.show_img = true

  


end

function Widget:set_quad()
  

  if self.hidden then
    self.number = 9
  end

  if self.flagged then
    
    self.number = 10
  end


  self.quad:setViewport(
    self.frame_size * self.number_to_quad[self.number].x,
    self.frame_size * self.number_to_quad[self.number].y,
    self.frame_size,
    self.frame_size
  )
  
end



function Widget:_is_hovering_over(x, y)
  if not self.revealing and not self.spawning then
    if self.collider:circle_rectangle(
                                        x, y, 5,
                                        self.position.x, self.position.y, 
                                        TILESIZE, TILESIZE
                                      ) then
      self.hovered = true
     
    else
      self.hovered = false
    end
    
    return self.hovered
  end
    return false
end


function Widget:tween_chain(tween_data, tween_type, bool, bool_off, tally, og_tally, seconds, og_seconds, dt)
  if bool then
    
    seconds = seconds - dt
    if tween_data[tally].time then


      if tween_data[tally].position ~= nil then
        FLUX.to(
                self.position, 
                tween_data[tally].og_time, 
                tween_data[tally].position
            ):ease(tween_type)--:oncomplete(move_to)
        
      end

      if tween_data[tally].scale ~= nil then
        FLUX.to(
              self.scale, 
              tween_data[tally].og_time, 
              tween_data[tally].scale
            ):ease(tween_type)--:oncomplete(move_to)
      end

      if tween_data[tally].angle ~= nil then
        FLUX.to(
            self.angle, 
            tween_data[tally].og_time, 
            tween_data[tally].angle
          ):ease(tween_type)--:oncomplete(move_to)
        
      end

      if tween_data[tally].rgb ~= nil then
        FLUX.to(
                self.rgb, 
                tween_data[tally].og_time, 
                tween_data[tally].rgb
            ):ease(tween_type)--:oncomplete(move_to)
        
      end

      if seconds <= 0 then
        tween_data[tally].time = tween_data[tally].time - dt
        if tween_data[tally].time <= 0 then
          tween_data[tally].time = tween_data[tally].og_time
          tally = tally + 1
          if tally > #tween_data then
            tally = og_tally
            if bool_off then
            
              seconds = og_seconds
              bool = false
           
            end

          end
        end
      end

      

    end


    

  
  end
  return tween_data, bool, tally, seconds
end


function Widget:update(dt)
 
  --[[
    --LUME TWEEN OPTIONS
        linear 
        quadin quadout quadinout 
        cubicin cubicout cubicinout 
        quartin quartout quartinout 
        quintin quintout quintinout 
        expoin expoout expoinout 
        sinein sineout sineinout 
        circin circout circinout 
        backin backout backinout 
        elasticin elasticout elasticinout
  ]]

  --if self.spawning then
    --self.spawn_seconds = self.spawn_seconds - dt
    --self.spawn_data[self.spawn_tally].time = self.spawn_data[self.spawn_tally].time - dt
    --self.spawning = self:chain_tween(self.spawn_data, "linear", self.spawn_tally, 0, self.spawning, dt)
    local data, bool, tally, seconds = self:tween_chain(
                                                        self.spawn_data,
                                                        "linear", 
                                                        self.spawning, true, 
                                                        self.spawn_tally, 0, 
                                                        self.spawn_seconds, self.og_spawn_seconds,
                                                        dt
    )

    self.spawn_data, self.spawning, self.spawn_tally, self.spawn_seconds = data, bool, tally, seconds
  

    data, bool, tally, seconds = self:tween_chain(
                                                        self.reveal_data,
                                                        "backinout", 
                                                        self.revealing, true, 
                                                        self.reveal_tally, 0, 
                                                        self.reveal_seconds, self.og_reveal_seconds,
                                                        dt
    )

    self.reveal_data, self.revealing, self.reveal_tally, self.reveal_seconds = data, bool, tally, seconds

    if self.reveal_tally == 1 then
      self.hidden = false
      self:set_quad()
    end

    data, bool, tally, seconds = self:tween_chain(
                                                        self.hover_data,
                                                        "backinout", 
                                                        self.hovered, false, 
                                                        self.hover_tally, 0, 
                                                        0, 0,
                                                        dt
    )

    self.hover_data, self.hovered, self.hover_tally = data, bool, tally

    if self.changing_color then
      
    end

  
  if not self.revealing and not self.hovered and not self.spawning and not self.changing_color then
    FLUX.to(self.scale, 0.3, VECTOR2(1.0, 1.0))
    FLUX.to(self.angle, 0.3, {radians = 0})
    FLUX.to(self.position, 0.3, self.play_position)
    

    --self.hover_timer:tween(1.5, self.scale, VECTOR2(1.0, 1.0), 'elastic')
  end
 
  --using FLUX
  FLUX.update(dt)

  --using Hump TIMER
  --self.hover_timer:update(dt)
  --self.reveal_timer:update(dt)
end


function Widget:draw(dt)
  
  if self.img and self.show_img then
    if self.changing_color then
      
    end
  
    love.graphics.draw(
                      self.img,
                      self.quad,
                      --position
                      self.position.x,
                      self.position.y,
                      --rotation(radians)
                      self.angle.radians,
                      --scale
                      self.scale.x, 
                      self.scale.y,
                      --offset
                      ( self.scale.x - 1 ) * self.dimension.x * 0.50,
                      ( self.scale.y - 1 ) * self.dimension.y * 0.50
    )

    if self.changing_color then
      
    end
  end

  if self.text then
    love.graphics.setColor(self.rgb.r ,self.rgb.g, self.rgb.b)
    love.graphics.setFont(self.font, self.font_size)
    --self:draw_hitbox()

    love.graphics.print(
        self.text, 
        self.position.x + self.text_offset.x,
        self.position.y + self.text_offset.y,
        --rotation(radians)
        self.angle.radians,
        --scale
        self.scale.x, 
        self.scale.y,
        --offset
        ( self.scale.x - 1 ) * self.dimension.x * 0.50,
        ( self.scale.y - 1 ) * self.dimension.y * 0.50
                )
    love.graphics.setColor(1, 1, 1)
  end

end








