local scale = {}
local _floor, _cos, _sin, _max, _abs, _sqrt, _min, _PI = math.floor, math.cos, math.sin, math.max, math.abs, math.sqrt, math.min, math.pi
scale.__index = scale
local collider = require "my_lib.collider"

-- this serves as a progressbar, a scale/slider, and a scrollbar

--where things that go up and down come from
--divides is how many units the guage bar is divided into
function scale:new(kwargs)--(bar_w,bar_h,wheel_a, wheel_r, divides,img)
  --scale = {}
  local self = setmetatable( {}, scale)
  self.collider = collider:new()
  -- The actual bar container
  self.area = kwargs.area or {x1 = -1, y1 = -1, x2 = -1, y2 = -1}

  self.has_scrollbar = kwargs.has_scrollbar or false
  --the scrollbar percentage of active area
  self.sbpct = 10
  
  
  self.show_progress = kwargs.show_progress or false
  self.rgb = kwargs.rgb or {r = -1, g = -1, b = -1, a = 1}
  self.mode =   kwargs.mode or ""
  
  self.rx = kwargs.rx or 0
  self.ry = kwargs.ry or 0
  self.segments = kwargs.segments or 0

  -- line width - an integer
  self.line_width = kwargs.line_width or 1
  -- line styles 
        -- smooth or rough
  self.line_style = kwargs.line_style or "smooth"
  

  -- the percentage of the area alloted in takes up in the contaier


  self.name = kwargs.name or "scale"

  -- the percentage of the of the scale's progress
  self.progress = kwargs.progress or 0

  self.show_scroll_limit = kwargs.show_scroll_limit or false


  self.is_vertical = kwargs.is_vertical or false
  self.is_horizontal = kwargs.is_horizontal or false
  self.is_circular = kwargs.is_circular or false
  self.is_flipped = kwargs.is_flipped or false
  self.mx = -1
  self.my = -1

  self.scroll_speed = 20

  --quad positions
  self.qx = 0
  self.qy = 0
  self.img = kwargs.img or ""
  self.quad = ""

  if self.img ~= "" then
    self.img = love.graphics.newImage(self.img)
    self.quad = love.graphics.newQuad(self.qx, self.qy, self.dimension.x, self.dimension.y, self.img)
  end

  
  
  

  return self
end

function scale:clamp(value, lower, upper)
  return _max(lower , _min(value, upper))
end

function scale:distance_to(x1, y1, x2, y2)
  return _sqrt((x2 - x1) ^ 2 + (y2 - y1) ^ 2)
end

function scale:lerp(a, b, pct)
  return a + (b - a) * pct
end

function scale:angle_to(x1, y1, x2, y2)
  return math.atan( y2 - y1, x2 - x1)
end


function scale:_is_hovering_over(x, y)
  --print(self.area.x1, self.area.y1, self.area.x2, self.area.y2, x, y)
  if self.collider:circle_rectangle(
                                      x, y, 5,
                                      self.area.x1, self.area.y1, 
                                      _abs(self.area.x2 - self.area.x1), _abs(self.area.y2 - self.area.y1)
                                    ) then
   return true
  end
  return false

end

function scale:_drag_value(x, y)
  -- to be put in the love.mousepressed function or the update(dt) function
  if self:_is_hovering_over(x, y) then
    local aw = _abs(self.area.x2 - self.area.x1)
    local ah = _abs(self.area.y2 - self.area.y1) 
    if self.is_circular then

      local ang_to = self:angle_to(
                      x, 
                      y, 
                      self.area.x2 - aw/2, 
                      self.area.y2 - ah/2
                    )
        
      self.progress = self:lerp(
                          self.progress,
                          ang_to/(2 * math.pi),
                          0.3
                  )
    

    elseif self.is_horizontal or self.is_vertical then
      
    
      if self.has_scrollbar then
        

        --the new divided area for the size/percentage of the scrollbar percentage
        local _x = 0 
        local _y = 0
        local _w = 0
        local _h = 0
        if self.is_horizontal then

          local sum = ((self.sbpct/100) * aw)

          _x = self.area.x1 + sum * 0.5
          _y = self.area.y1 
          _w = aw - sum 
          _h = self.area.y2 
          
          self.progress = self:clamp((x - _x)/_w * 100, 0, 100)
          

        elseif self.is_vertical then

          local sum = ((self.sbpct/100) * ah)

          _x = self.area.x1 
          _y = self.area.y1 + sum * 0.5
          _w = self.area.x2 
          _h = ah - sum 

          self.progress = self:clamp((y - _y)/_h * 100, 0, 100)
      
        end

      else

        if self.is_horizontal then
          self.progress = self:clamp((1 - _abs(self.area.x2 - x)/aw) * 100, 0, 100)
          --[[
          self.progress = self:clamp(
                    self:lerp(
                              self.progress,
                              (1 - _abs(self.area.x2 - x)/aw) * 100,
                              0.3
                    ), 
                    0,
                    100
          )
                              ]]
        elseif self.is_vertical then
          self.progress = self:clamp((1 - _abs(self.area.y2 - y)/ah) * 100, 0, 100)
          --[[
          self.progress = self:clamp(
                    self:lerp(
                              self.progress,
                              (1 - _abs(self.area.y2 - y)/ah) * 100,
                              0.3
                    ), 
                    0,
                    100
          )
          ]]
        end
      end
    
    end
  end
end

function scale:_is_wheel_moved(x, y,  dy)
  if self:_is_hovering_over(x, y) then
    
    self.progress = self:clamp(self.progress + dy, 0, 100)
    
  end

end

function scale:_is_mouse_pressed(x, y, mouse_int)
    --to be placed in love.mousepressed
  -- key is tapped
  if self:_is_hovering_over(x, y) then
    return true
  end

  
end

function scale:_is_mouse_down(x, y, mouse_int)
  -- key is continously held
  if self:_is_hovering_over(x, y) then
 
    if love.mouse.isDown(mouse_int) then
        return true
    end
  end
  return false
  
end

function scale:_is_key_pressed(x, y, key)
    --to be placed in love.keypressed(key)
  -- key is tapped
  if self:_is_hovering_over(x, y) then
    return true
  end

  
end

function scale:_is_key_down(x, y, key)
  -- key is continously held
  if self:_is_hovering_over(x, y) then
    if love.keyboard.isDown(key) then
        return true
    end
  end
  return false
  
end


--methods which act on the actor regardless

function scale:_set_progress(progress)
  self.progress = progress
end

function scale:_get_progress()
  return self.progress
end

--one actually draws the other draws a box
function scale:draw()
  --love.graphics.draw(self.img,self.quad,self.gx,self.gy)

  --local has_container_color = self.crgb.r ~= -1 and self.crgb.g ~= -1 and self.crgb.b
  local has_progress_color = self.rgb.r ~= -1 and self.rgb.g ~= -1 and self.rgb.b ~= -1
      

  local aw = _abs(self.area.x2 - self.area.x1)
  local ah = _abs(self.area.y2 - self.area.y1) 


  local percentage = (self.progress/100)
 
  

  
  if self.is_circular then

    local r_min = _min(aw, ah)
    local cpct = (self.progress/100)

    

    if has_progress_color then
      love.graphics.setColor(self.rgb.r, self.rgb.g, self.rgb.b, self.rgb.a)
    end

    if self.mode == "line" then
      love.graphics.setLineWidth(self.line_width)
      love.graphics.setLineStyle(self.line_style)
    end

      if self.mode ~= "" then

          love.graphics.arc(
                            self.mode,
                            self.area.x1, 
                            self.area.y1,
                            r_min,  
                            cpct * 2 * math.pi, 
                            2 * math.pi
                          )

      end

    if self.mode == "line" then
      love.graphics.setLineWidth(1)
      love.graphics.setLineStyle("smooth")
    end

    if has_progress_color then
      love.graphics.setColor(1, 1, 1, 1) 
    end

    

  elseif self.is_horizontal or self.is_vertical then
    
    local _x = 0 
    local _y = 0
    local _w = 0
    local _h = 0

    if has_progress_color then
      love.graphics.setColor(self.rgb.r, self.rgb.g, self.rgb.b, self.rgb.a)
    end

    if self.mode == "line" then
      love.graphics.setLineWidth(self.line_width)
      love.graphics.setLineStyle(self.line_style)
    end


        if self.mode ~= "" then

          if self.has_scrollbar then
            
            --the new divided area for the size/percentage of the scrollbar percentage
            
            if self.is_horizontal then

              local sum = ((self.sbpct/100) * aw)
              local start_x = self.area.x1 + sum * 0.5
              local end_w = aw - sum

              -- the active area of the scrollbar
              if self.show_scroll_limit then
                love.graphics.rectangle(
                                            "line", 
                                            start_x, 
                                            self.area.y1, 
                                            end_w, 
                                            ah,
                                            self.rx,
                                            self.ry,
                                            self.segments
                                          )
              end
                                      
  
              -- the actual bar itself
              love.graphics.rectangle(
                                          self.mode, 
                                          start_x + end_w * percentage - sum * 0.5, 
                                          self.area.y1, 
                                          sum, 
                                          ah,
                                          self.rx,
                                          self.ry,
                                          self.segments
                                        )

              _x = start_x + end_w * percentage - sum * 0.5
              _y = self.area.y1
              _w = sum
              _h = ah

            elseif self.is_vertical then
              local sum = ((self.sbpct/100) * ah)
              local start_y = self.area.y1 + sum * 0.5
              local end_h = (ah - sum)
              
              -- the active area of the scrollbar
              if self.show_scroll_limit then
                love.graphics.rectangle(
                                            "line", 
                                            self.area.x1, 
                                            start_y, 
                                            aw, 
                                            end_h,
                                            self.rx,
                                            self.ry,
                                            self.segments
                                          )
              end

              love.graphics.rectangle(
                                          self.mode, 
                                          self.area.x1, 
                                          start_y + end_h * percentage - sum * 0.5, 
                                          aw, 
                                          sum,
                                          self.rx,
                                          self.ry,
                                          self.segments
                                        )

              _x = self.area.x1
              _y = start_y + end_h * percentage - sum * 0.5
              _w = aw
              _h = sum
              
            end
            

          else
            if self.is_horizontal then
              --print("assas")
              

              if self.is_flipped then

                _x = self.area.x1 + aw * percentage
                _y = self.area.y1
                _w = aw - aw * percentage
                _h = ah
              
              else

                _x = self.area.x1
                _y = self.area.y1
                _w = aw * percentage
                _h = ah

              end


            elseif self.is_vertical then
              
              if self.is_flipped then
       
                _x = self.area.x1
                _y = self.area.y1 + ah * percentage
                _w = aw
                _h = ah - ah * percentage
                
              else

                _x = self.area.x1
                _y = self.area.y1
                _w = aw
                _h = ah * percentage
                                
              end

            end
          end


        end

    love.graphics.rectangle(
                            self.mode, 
                            _x, 
                            _y, 
                            _w, 
                            _h,
                            self.rx,
                            self.ry,
                            self.segments
                          )

    if self.mode == "line" then
      love.graphics.setLineWidth(1)
      love.graphics.setLineStyle("smooth")
    end

    if has_progress_color then
      love.graphics.setColor(1, 1, 1, 1) 
    end

  end

  

end



return scale



