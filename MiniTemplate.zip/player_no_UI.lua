require "entity_2D"
require "bullet"
local gauge = require "gauge"

Player = ENTITY:extend()



function Player:new(position_table,dimension_table,hp,image_path,quad_x,quad_y,in_world,group_table)
  Player.super.new(self,
    position_table,
    dimension_table,
    hp,
    image_path,
    quad_x,
    quad_y,
    in_world,
    group_table)
  
  --size of single frame in spritesheer
  
  --self.frame_size = 24
  self.max_speed = 200
  self.rotation_speed = 200
  self.button_tile_input = true
  self.mouse_tile_input = false
  --mouse offeset
  self.mx = 0
  self.my = 0
  self.vy = 0

  self.walkable_tile = 0
  self.unreachable_tile = 1
  self.mouse_vector = VECTOR2(self.mx, self.my)

  --size of cell in the spritesheet
  self.frame_size = TILESIZE

  -- primitive state machine
  -- player animations: in the case of the current spritesheet, "pc.png", quad_y doesn't matter
  -- time is the seconds until the next animation frame
  local idle_time = 0.300
  self.idle_anim  = {time = idle_time, quad_x = 0, quad_y = 4, og_time = idle_time, og_quad_x = 0, og_quad_y = 0, frames = 2, name = "idle"}
  
  local walk_time = 0.270
  self.walk_anim  = {time = walk_time, quad_x = 0, quad_y = 0, og_time = walk_time, og_quad_x = 0, og_quad_y = 0, frames = 4, name = "walk"}
  
  local hurt_time = 0.125
  self.hurt_anim  = {time = hurt_time, quad_x = 0, quad_y = 6, og_time = hurt_time, og_quad_x = 0, og_quad_y = 0, frames = 1, name = "hurt"}
  
  local dying_time = 0.300
  self.dying_anim = {time = dying_time, quad_x = 0, quad_y = 6, og_time = dying_time, og_quad_x = 1, og_quad_y = 0, frames = 2, name = "dying"}
  
  local dead_time = 0.300
  self.dead_anim  = {time = dead_time, quad_x = 1, quad_y = 6, og_time = dead_time, og_quad_x = 1, og_quad_y = 0, frames = 0, name = "dead"}
  
  local attack_time = 0.300
  self.attack_anim   = {time = attack_time, quad_x = 0, quad_y = 5, og_time = attack_time, og_quad_x = 0, og_quad_y = 0, frames = 3, name = "hit"}
  
  local defend_time = 0.125
  self.defend_anim  = {time = defend_time, quad_x = 0, quad_y = 1, og_time = defend_time, og_quad_x = 0, og_quad_y = 0, frames = 2, name = "defend"}
  
  local shoot_time = 0.400
  self.shoot_anim  = {time = shoot_time, quad_x = 0, quad_y = 2, og_time = shoot_time, og_quad_x = 0, og_quad_y = 0, frames = 2, name = "cast"}
  
  --how long each state lasts in seconds
  self.seconds_attack = self.attack_anim.og_time * self.attack_anim.frames
  self.seconds_hurt = 0.3
  self.seconds_flash = 0.1
  self.seconds_defend = 0.5
  self.seconds_dying = self.dying_anim.og_time * self.dying_anim.frames
  

  self.seconds_refill = 0.8
  self.seconds_fire = 0.3






  self.fade_time = 0
  self.state = "idle"
  self.states = {
    "idle",
    "walk",
    "hurt",
    "attack",
    "dying",
    "dead",
    "defend",
    "shooting"
  }


  --shader stuff
  self.flash_shader = love.graphics.newShader("flash.glsl")
  self.fade_shader = love.graphics.newShader("fade.glsl")
  self.fade_duration = 1.5

  self.bullet_img_path = PLAYER_IMAGE_PATH
  self.og_hurt_t = 0.3

  
  
  --slash hitbox stuff
  
  self.slash_mode = 'line'
  
  local hitbox_dist = 12

  --the slash hitbox, a trapezoid
  local tx1 = self.position.x + self.dimension.x/2 + hitbox_dist
  local ty1 = self.position.y + self.dimension.y/2 - self.frame_size/1.5

  local tx2 = self.position.x + self.dimension.x/2 + hitbox_dist
  local ty2 = self.position.y + self.dimension.y/2 + self.frame_size/1.5
  
  local tx3 = self.position.x + self.dimension.x/2 + hitbox_dist + self.frame_size/2 
  local ty3 = math.abs(ty2 - ty1) - (math.abs(ty2 - ty1)/4) + ty1

  local tx4 = self.position.x + self.dimension.x/2 + hitbox_dist + self.frame_size/2 
  local ty4 = math.abs(ty2 - ty1)/4 + ty1

  self.slash_anim = {time = .125, quad_x = 3, quad_y = 5, og_time = .125, og_quad_x = 3, og_quad_y = 5, frames = 1, name = "slash"}
  --self.slash_anim = {t = .125, qx = 3, qy = 5, ot = .125, oqx = 3, oqy = 5, f = 1, name = "slash"}
  self.slash_img = love.graphics.newImage("assets/pc.png")
  self.slash_quad = love.graphics.newQuad(3 * TILESIZE, 5 * TILESIZE, TILESIZE,TILESIZE,self.slash_img)
  
  --x , y, x, y, etc
  self.slash_verts = {
    tx1, ty1, 
    tx2, ty2,  
    tx3, ty3, 
    tx4, ty4
  }

  --
  self.total_ammo = 30
  self.current_ammo = 0
  self.fire_rate = 0.08
  self.refill_rate = 0.23
  self.hp = 5
  

  

  --gauge examples
  self.ammo_value_h = gauge:new(
                              self.position.x - self.dimension.x/2, 
                              self.position.y - self.dimension.y, 
                              self.dimension.x  * 2,
                              6,
                              2*math.pi,
                              15,
                              self.total_ammo,
                              nil
                          )
  self.ammo_bar_h = gauge:new(
                            self.position.x - self.dimension.x/2, 
                            self.position.y - self.dimension.y, 
                            self.dimension.x  * 2,
                            6,
                            2*math.pi,
                            15,
                            self.total_ammo,
                            nil
                          )
  
  

  self.ammo_value_w = gauge:new(
                              self.position.x + self.dimension.x/2, 
                              self.position.y - self.dimension.y*(3/2), 
                              self.dimension.x  * 2,
                              6,
                              2*math.pi,
                              5,
                              self.total_ammo,
                              nil
                          )
  self.ammo_wheel = gauge:new(
                            self.position.x + self.dimension.x/2, 
                            self.position.y - self.dimension.y*(3/2), 
                            self.dimension.x  * 2,
                            6,
                            0,
                            5,
                            self.total_ammo,
                            nil
                          )
  


  self.hp_bar_h = gauge:new(
                          self.position.x - self.dimension.x/2, 
                          self.position.y - self.dimension.y/2, 
                          self.dimension.x  * 2,
                          6,
                          2*math.pi,
                          15,
                          self.hp,
                          nil
                        )
  self.hp_value_h = gauge:new(
                            self.position.x - self.dimension.x/2, 
                            self.position.y - self.dimension.y/2, 
                            self.dimension.x  * 2,
                            6,
                            2*math.pi,
                            15,
                            self.hp,
                            nil
                          )
  
  self.current_anim = self.idle_anim
  self.has_input = false
  
end


function Player:update_other_hitbox()
  
    --moving the slash hitbox

    local hitbox_dist = 12
    local tx1 = self.position.x + self.dimension.x/2 + hitbox_dist
    local ty1 = self.position.y + self.dimension.y/2 - self.frame_size/1.5

    local tx2 = self.position.x + self.dimension.x/2 + hitbox_dist
    local ty2 = self.position.y + self.dimension.y/2 + self.frame_size/1.5
    
    local tx3 = self.position.x + self.dimension.x/2 + hitbox_dist + self.frame_size/2 
    local ty3 = math.abs(ty2 - ty1) - (math.abs(ty2 - ty1)/4) + ty1

    local tx4 = self.position.x + self.dimension.x/2 + hitbox_dist + self.frame_size/2 
    local ty4 = math.abs(ty2 - ty1)/4 + ty1

    self.slash_verts[1] = tx1
    self.slash_verts[2] = ty1
    self.slash_verts[3] = tx2
    self.slash_verts[4] = ty2
    self.slash_verts[5] = tx3
    self.slash_verts[6] = ty3
    self.slash_verts[7] = tx4
    self.slash_verts[8] = ty4

    
    for i = 1, #self.slash_verts, 2  do
      local x_ind = i
      local y_ind = i + 1
      
      
      --self.slash_verts[x_ind] = self.slash_verts[x_ind] + self.velocity.x * dt
      --self.slash_verts[y_ind] = self.slash_verts[y_ind] + self.velocity.y * dt
    
      --moving the positions
      local x,y = self.slash_verts[x_ind], self.slash_verts[y_ind]
      --rotating the hitbox
      local tx, ty = self.position.x + self.dimension.x/2,  self.position.y + self.dimension.y/2
      --making origin centric
      x, y = self.transformer:translate_2D(-tx, -ty, x, y)
      --applying transformation
      x, y =self.transformer:rotate_2D(self.angle_convert:degrees_to_radians(self.angle), x, y)
      --moving back to original position
      self.slash_verts[x_ind], self.slash_verts[y_ind] = self.transformer:translate_2D(tx, ty, x, y)


    
    end
end


function Player:fire_bullet()
  
  -- with hump timer
  -- without hump's Timer
  -- updates angle
  local angle = LUME.angle(
                        self.position.x + (self.dimension.x/2),
                        self.position.y + (self.dimension.y/2), 
                        self.mouse_vector.x, 
                        self.mouse_vector.y
                      )

  self.angle = self.angle_convert:radians_to_degrees(angle)

  self.sin = math.sin(angle)
  self.cos = math.cos(angle)

  

  --adding randoness to the bullet launch
  --angle = self.angle_convert:degrees_to_radians(self.angle + love.math.random(-15, 15))
  local a_sin = math.sin(angle)
  local a_cos = math.cos(angle)


  --print("yep")
  local dist = math.max(WORLD_LEVEL_HEIGHT, WORLD_LEVEL_WIDTH) * 5
  local x_target = self.position.x + self.dimension.x/2 + dist * a_cos
  local y_target = self.position.y + self.dimension.y/2 + dist * a_sin
  local target_position = VECTOR2(x_target, y_target)
  local position = {x = self.line.x2, y = self.line.y2}

  local dimesions = {w = 5, h = 5}

  
  local t = Bullet(
    position,
    dimesions,
    10,
    self.bullet_img_path,
    0,
    0,
    false,
    PROJECTILES
  )
  t.sample_anim = {time = .125, quad_x = 0, quad_y = 3, og_time = .125, og_quad_x = 0, og_quad_y = 3, frames = 4, name = "bullet"}
  t.quad = love.graphics.newQuad(
                                  t.sample_anim.quad_x * TILESIZE, 
                                  t.sample_anim.quad_y * TILESIZE, 
                                  TILESIZE,
                                  TILESIZE,
                                  t.img
                          )

  
  
  
  --bullet owner ship
  t.owner = "player"
  --adding velocity so bullets have a constant speed as the player moves
  t.move_speed = self.move_speed + t.move_speed
  t.target_position = target_position
  

  --meant to help the hitbox keep up with the sudden velocity change
  local last_pos_x = self.position.x
  local last_pos_y = self.position.y

  --knockback, works when friction is less than 1
  --self.velocity.x = LUME.lerp(self.velocity.x, self.velocity.x + -t.move_speed * a_cos, self.acceleration/2)
  --self.velocity.y = LUME.lerp(self.velocity.y, self.velocity.y + -t.move_speed * a_sin, self.acceleration/2)

  --self.seconds_fire = 0.20 --+ love.math.random(0.05, 0.08) 
  
  local pos_x_change = self.position.x - last_pos_x
  local pos_y_change = self.position.y - last_pos_y
  
  --[[
  for i = 1, #self.hitbox, 2  do
    local x_ind = i
    local y_ind = i + 1
    --keeping the hitbox aligned with the position
    self.hitbox[x_ind] = self.hitbox[x_ind] + pos_x_change
    self.hitbox[y_ind] = self.hitbox[y_ind] + pos_y_change
  end
  ]]--
    
  --end
  
end

function Player:fire_bullets(dt)
  -- without hump's Timer
  -- updates angle
  local angle = LUME.angle(
                        self.position.x + (self.dimension.x/2),
                        self.position.y + (self.dimension.y/2), 
                        self.mouse_vector.x, 
                        self.mouse_vector.y
                      )

  self.angle = self.angle_convert:radians_to_degrees(angle)

  self.sin = math.sin(angle)
  self.cos = math.cos(angle)

  --self.fire_rate = self.fire_rate - dt
  self.seconds_fire = self.seconds_fire - dt
  --self.refill_rate = 0.1 + dt
  --if self.fire_rate <= 0 and self.current_ammo > 0 then
  if self.seconds_fire <= 0 and self.current_ammo > 0 then
    self.current_ammo = self.current_ammo - 1
    --self.seconds_fire = 1
    --adding randoness to the bullet launch
    --angle = self.angle_convert:degrees_to_radians(self.angle + love.math.random(-15, 15))
    local a_sin = math.sin(angle)
    local a_cos = math.cos(angle)


    --print("yep")
    local dist = math.max(WORLD_LEVEL_HEIGHT, WORLD_LEVEL_WIDTH) * 5
    local x_target = self.position.x + self.dimension.x/2 + dist * a_cos
    local y_target = self.position.y + self.dimension.y/2 + dist * a_sin
    local target_position = VECTOR2(x_target, y_target)
    local position = {x = self.line.x2, y = self.line.y2}

    local dimesions = {w = 5, h = 5}

    
    local t = Bullet(
      position,
      dimesions,
      10,
      self.bullet_img_path,
      0,
      0,
      false,
      PROJECTILES
    )
    t.sample_anim = {time = .125, quad_x = 0, quad_y = 3, og_time = .125, og_quad_x = 0, og_quad_y = 3, frames = 4, name = "bullet"}
    t.quad = love.graphics.newQuad(
                                    t.sample_anim.quad_x * TILESIZE, 
                                    t.sample_anim.quad_y * TILESIZE, 
                                    TILESIZE,
                                    TILESIZE,
                                    t.img
                            )

   
    
    
    --bullet owner ship
    t.owner = "player"
    --adding velocity so bullets have a constant speed as the player moves
    t.move_speed = self.move_speed + t.move_speed
    t.target_position = target_position
    

    --meant to help the hitbox keep up with the sudden velocity change
    local last_pos_x = self.position.x
    local last_pos_y = self.position.y

    --knockback, works when friction is less than 1
    --self.velocity.x = LUME.lerp(self.velocity.x, self.velocity.x + -t.move_speed * a_cos, self.acceleration/2)
    --self.velocity.y = LUME.lerp(self.velocity.y, self.velocity.y + -t.move_speed * a_sin, self.acceleration/2)

    --self.seconds_fire = 0.20 --+ love.math.random(0.05, 0.08) 
    
    local pos_x_change = self.position.x - last_pos_x
    local pos_y_change = self.position.y - last_pos_y
    
    --[[
    for i = 1, #self.hitbox, 2  do
      local x_ind = i
      local y_ind = i + 1
      --keeping the hitbox aligned with the position
      self.hitbox[x_ind] = self.hitbox[x_ind] + pos_x_change
      self.hitbox[y_ind] = self.hitbox[y_ind] + pos_y_change
    end
    ]]--
      
    --end
    


  end
  
end

function Player:restart()
  self.is_dead = false
  self.is_dying = false
  self.state = "idle"
  self.current_anim = self.idle_anim
  self.fade_time = 0
  self.fade_duration = 1.5
  self.fade_shader:send("time", self.fade_time)
  self.fade_shader:send("duration", self.fade_duration)
  love.graphics.setShader(self.fade_shader)
  love.graphics.setShader()
end

function Player:manage_state()

  if VISIBLE.IS_ANIMATIONS then



    local LMB = love.mouse.isDown(1)
    local RMB = love.mouse.isDown(2)
    local up = love.keyboard.isDown('up','w')
    local down = love.keyboard.isDown('down','s')
    local right = love.keyboard.isDown('right','d')
    local left = love.keyboard.isDown('left','a')
    local up_right = up and right
    local up_left = up and left
    local down_right = down and right
    local down_left = down and left

    self.has_input = (

      LMB or
      RMB or 
      up or
      down or
      left or
      right or
      up_right or
      up_left or 
      down_right or
      down_left 

    )

    local other_states = (
    
                          self.state == "attack" or 
                          self.state == "defend" or
                          self.state == "hurt" or
                          self.state == "dying" or
                          self.state == "dead" 
                         
                        
                        )

    local negative_states = (
                        self.state == "hurt" or
                        self.state == "dying" or
                        self.state == "dead"
                      )
                        
    local moving = self.velocity.x ~= 0 or self.velocity.y ~= 0
    --print(moving)
    
    --print(negative_states)
    
    --flipping character direction
    if MOVEMENT.IS_CLICK then
      if self.position.x + self.dimension.x/2 < self.mouse_vector.x then
        self.fx = -1
      else
        self.fx = 1
      end

      
      
    else
      if self.velocity.x > 0 then
        self.fx = -1
      elseif self.velocity.x < 0 then
        self.fx = 1
      end


    end



    

    if not negative_states  and not other_states then
      --if not other_states then
        
      
      if LMB then
        self.state = "walk"
      else
        self.state = "idle"
        
      end

      if moving then
      self.state = "walk"


      else
        self.state = "idle"
      end

      if RMB then
        self.state = "shooting"
      end

      

      
      --end

      
        
      

    end



    if self.state == "attack" then
      self.slash_mode = 'fill'

      self.seconds_attack = self.seconds_attack - self.delta_time
      if self.seconds_attack <= 0 then
        
        self.state = "idle"
        self.slash_mode = 'line'
        self.seconds_attack = self.attack_anim.og_time * self.attack_anim.frames
        
      end

      self.current_anim = self.attack_anim

    elseif self.state == "defend" then
        
      self.seconds_defend = self.seconds_defend - self.delta_time
      if self.seconds_defend <= 0 then
        
        self.state = "idle"
        self.seconds_defend = 0.5
        
      end

      self.current_anim = self.defend_anim

    elseif self.state == "hurt" then
    
      self.seconds_hurt = self.seconds_hurt - self.delta_time
      if self.seconds_hurt <= 0 then
        
        self.state = "idle"
        self.seconds_hurt = 0.3
        self.seconds_flash = 0.1
        if self.hp <= 0 then
    
          self.state = "dying"
        end
        
      end


      self.current_anim = self.hurt_anim
    
    elseif self.state == "dying" then
      

      self.seconds_dying = self.seconds_dying - self.delta_time
      if self.seconds_dying <= 0 then
        
        self.state = "idle"
        self.seconds_dying = self.dying_anim.og_time * self.dying_anim.frames
        if self.hp <= 0 then
    
          self.state = "dead"
        end
        
      end

      self.current_anim = self.dying_anim
    elseif self.state == "shooting" then
      self.current_anim = self.shoot_anim
    
    elseif self.state == "dead" then
      if self.fade_time < self.fade_duration then
        self.fade_time = self.fade_time + self.delta_time
        self.fade_shader:send("time", self.fade_time)
        self.fade_shader:send("duration",self.fade_duration)
      else
        self.fade_shader:send("time", self.fade_duration)
      end
      self.current_anim = self.dead_anim
    elseif self.state == "walk" then
      self.current_anim = self.walk_anim
      
    elseif self.state == "idle" then
      self.current_anim = self.idle_anim
    end

    
    
    
  end


end


function Player:update(dt)
  --hump camera
  local mx,my = CAM:worldCoords(love.mouse.getPosition())
  
  --kikito's gamera
  --local mx, my = GAM:toWorld(love.mouse.getPosition())
  --gam:setPosition(self.x + self.w/2,self.y + self.h/2)
  CAM:lookAt(self.position.x + self.dimension.x/2,self.position.y + self.dimension.y/2)
  self.mx = mx 
  self.my = my 
  self.mouse_vector.x = self.mx 
  self.mouse_vector.y = self.my
  

  self.delta_time = dt

  local LMB = love.mouse.isDown(1)
  local RMB = love.mouse.isDown(2)
  local up = love.keyboard.isDown('up','w')
  local down = love.keyboard.isDown('down','s')
  local right = love.keyboard.isDown('right','d')
  local left = love.keyboard.isDown('left','a')
  local up_right = up and right
  local up_left = up and left
  local down_right = down and right
  local down_left = down and left

  



  --self:update_line_angle(dt)

  --current movement options
  
 
    
  

  --self:tank_movement(dt)
  self:topdown_2d_movement(dt)
  --self:platformer_2d_movement(dt)
  --self:tile_button_movement(self.delta_time, self.walkable_tile, self.unreachable_tile)
  --self:follow_target_tile(self.delta_time, self.walkable_tile, self.mouse_vector)


  if MOVEMENT.IS_CLICK then
    --left mouse button
    if LMB then
      --updates angle and position
      self:follow_target(dt, self.mouse_vector, true)
    else
      self.velocity = VECTOR2.zero
    end
  end


    -- shoot
    -- right mouse button
    if RMB then
      -- uses original code 
      -- uses the end of the line as the place 
      -- where the bullet initializes angle 
      --self:fire_bullets(dt)

      
      self.seconds_fire = self.seconds_fire - self.delta_time
      if self.seconds_fire <= 0 and self.current_ammo > 0 then
        --print("fired")
        self.current_ammo = self.current_ammo - 1
        self.seconds_fire = 0.1
        self:fire_bullet()
        --print(("secondes to fire %f"):format(self.seconds_fire))
      end
    

      
    else
      self.seconds_refill = self.seconds_refill - self.delta_time
      if self.seconds_refill <= 0 and self.current_ammo ~= self.total_ammo then
        --print("fired")
        self.current_ammo = self.current_ammo + 1
        self.seconds_refill = 0.25
        
      end
    end




  -- slashing


    if love.keyboard.isDown('z') then
      if self.state ~= "attack" then

        self.state = "attack"
        --print("yes")
      end

    end

  
  
  -- hurting self

  if love.keyboard.isDown('c') then
    --for testing
    if self.state ~= "hurt" and self.hp > 0 then
      self.hp = self.hp - 1
      self.state = "hurt"
    end
    
    

  end

  -- defending
  if love.keyboard.isDown('x') then
    if self.state == "idle" or self.state == "walk" then
      self.state = "defend"
    end

  end

  
  


  

  


  
  --print(self.delta_time)
  --updates line angle: all below are in the entity_2D file
  self:update_line_angle()
  self:update_other_hitbox()
  self:update_hitbox_position()

  self.ammo_value_h:set_value(self.current_ammo, false, true, false)
  self.ammo_value_w:set_value(self.current_ammo, false, false, true)
  self.hp_value_h:set_value(self.hp, false, true, false)
  self:manage_state()
  
end

function Player:draw()
  
  --love.graphics.print("HP: ", self.position.x - self.dimension.x, self.position.y - self.dimension.y/2)
  

    self.hp_bar_h:display_bar('line', self.position.x - self.dimension.x/2, self.position.y - self.dimension.y/2)
    self.hp_value_h:display_bar('fill', self.position.x - self.dimension.x/2, self.position.y - self.dimension.y/2)
  


    --love.graphics.print("Ammo: ", self.position.x + self.dimension.x, self.position.y - self.dimension.y * (3/2))
    self.ammo_bar_h:display_bar('line', self.position.x - self.dimension.x/2, self.position.y - self.dimension.y)
    self.ammo_value_h:display_bar('fill', self.position.x - self.dimension.x/2, self.position.y - self.dimension.y)
 
    self.ammo_wheel:display_wheel('line', self.position.x + self.dimension.x/2, self.position.y - self.dimension.y * (3/2))
    self.ammo_value_w:display_wheel('fill', self.position.x + self.dimension.x/2, self.position.y - self.dimension.y * (3/2))
    
  
  

    -- the line that shows the angle: this is in entity_2D
    self:draw_line()
  
  

    --if self.single_tile_input or self.mouse_tile_input then
    local boxx, boxy = self:world_to_array2d(self.mx, self.my) 
    local boxx, boxy = self:array2d_to_world(boxx, boxy)
    
    love.graphics.rectangle(
      "line",
      boxx,
      boxy,
      TILESIZE,
      TILESIZE
    )

  

  
  


    --the player's hitbox
    love.graphics.polygon("line", self.hitbox)
    if ACTION.IS_MELEE then

        -- the slash hitbox
        love.graphics.polygon(self.slash_mode, self.slash_verts)

    end

  --self:display('line')

  

end





