require "entity_2D"


Bullet = ENTITY:extend()

function Bullet:new(position_table,dimension_table,hp,image_path,quad_x,quad_y,in_world,group_table)
    Bullet.super.new(self,
    position_table,
    dimension_table,
    hp,
    image_path,
    quad_x,
    quad_y,
    in_world,
    group_table)
    self.target_position = self.position
    self.lifetime = 1.2
    self.collided = false
    self.move_speed = 80
    self.owner = ""
    self.r = math.max(dimension_table.w, dimension_table.h)
    self.frame_size = TILESIZE
    --self.bullet_anim = {time = .125, quad_x = 0, quad_y = 3, og_time = .125, og_quad_x = 0, og_quad_y = 3, frames = 4, name = "bullet"}
    --self.slash_anim = {t = .125, qx = 3, qy = 5, ot = .125, oqx = 3, oqy = 5, f = 1, name = "slash"}
    --self.bullet_img = love.graphics.newImage(image_path)
    --[[self.bullet_quad = love.graphics.newQuad(
                                                self.bullet_anim.quad_x * TILESIZE, 
                                                self.bullet_anim.quad_y * TILESIZE, 
                                                TILESIZE,
                                                TILESIZE,
                                                self.bullet_img
                                        )
    ]]--

    
end

function Bullet:update(dt)
    self.lifetime = self.lifetime - dt
    if self.lifetime <= 0 then
        local ind = 1
        for i, v in ipairs(PROJECTILES) do   
            if v == self then
                ind = i
                break
            end
        end
        self:remove_from_group(PROJECTILES, ind)
    end

    if self.target_position then
        self:follow_target(dt, self.target_position, false)
    end
    if self.quad ~= nil then
        self:animate(dt, self.sample_anim, self.quad)
    end

    --for enemies that don't exist, but a useful structure nonetheless

    for _, v in ipairs(ENEMIES) do
        if self.owner == "player" then
            if v.name == 'tris' then
                if v.state ~= "hurt" and v.state ~= "dying" then
                    if self.collider:polygon_circle(v.hitbox, 
                                                    self.position.x, 
                                                    self.position.y, 
                                                    self.r) then
                        v.state = "hurt"
                        v.state_timer = 0.0
                        v.hp = v.hp - 1
                        self.lifetime = 0
                    end
                end
            elseif v.name == 'doppel' then
                if v.state ~= "hurt" then
                    if self.collider:polygon_circle(v.hitbox, 
                                                    self.position.x, 
                                                    self.position.y, 
                                                    self.r) then
                        v.state = "hurt"
                        v.hp = v.hp - 1
                        self.lifetime = 0
                    end
                end
            end
        end
    end
    
end

function Bullet:arena_destroy()
  
    if not self.collider:circle_circle(self.position.x, self.position.y, self.r, CIRCLE_ARENA.x, CIRCLE_ARENA.y, CIRCLE_ARENA.r) then
      --CIRCLE_ARENA.fill = "fill"
      self.lifetime = 0
    else
      --CIRCLE_ARENA.fill = "line"
    end
    
    
end


function Bullet:draw()
    --if VISIBLE.IS_ANIMATIONS then
        if self.quad ~= nil then
            
            love.graphics.draw(self.img,
                                self.quad,
                                self.position.x,
                                self.position.y,
                                0, 
                                1, 
                                1, 
                                self.frame_size/2,--self.frame_size,
                                self.frame_size/2
                            
                            )
        end
    --end

    --if VISIBLE.IS_COLLIDERS then
        local mode = ""
        if self.owner == "player" then
            mode = "line"
        else
            mode = "fill"
        end
        love.graphics.circle(mode, self.position.x, self.position.y, self.r, 5)
    --end
end