
local button = require "my_lib.button"
local scale = require "my_lib.scale"
local GUIM = require "my_lib.GUIM" 
local how_UI = nil
local r, g, b, a = love.math.colorFromBytes(0, 0, 0, 1) --(172, 170, 189)

local font_path_1 = "fonts//VT323-Regular.ttf"
local font_path_2 = "fonts//Kaph-Regular.ttf"
local font_path_3 = "font//comic_neue_bold_19.ttf"


local full_region = nil
local main_region = nil
local context_scl = nil
local switch_region = nil
local switch_idx = nil
local context_idx = nil

local mx = -1
local my = -1

local black = {r = 0, g = 0, b = 0, a = 1}
local white = {r = 1, g = 1, b = 1, a = 1}
local gray  = {r = 0.5, g = 0.5, b = 0.5, a = 1}

---------------------------------------------------------------------------------------------------------------
-- Template Menu - with all? the things HUMP's gamestate allows 
---------------------------------------------------------------------------------------------------------------

local function setup_UI( ... )
    how_UI = GUIM:new()
  how_UI.show_index = false
  how_UI.show_widget = false
  local k = ""
  full_region = how_UI:add_area(
            {
              area = {
              x1 = 0,
              y1 = 0,
              x2 = SCREEN_WIDTH,
              y2 = SCREEN_HEIGHT
              },
              fill = "",
              mode = "fill",
              ext_anchor = "",
              int_anchor = "N",
              parent_idx = nil,
              rgb = black
              --[[
              rgb = {
                r = r,
                g = g,
                b = b,
                a = a
              }]]

            }
  )

  main_region = how_UI:add_area(
            {
              --width_pct = 90,
              --height_pct = 90,
              min_pct = 90,
              fill = "",
              mode = "",
              ext_anchor = "",
              int_anchor = "C",
              parent_idx = full_region,
              rgb = white,

            }
  )

  --[[
  button_region = how_UI:add_area(
            {
              --width_pct = 85,
              --height_pct = 90,
              min_pct = 95,
              fill = "",
              mode = "",
              ext_anchor = "",
              int_anchor = "N",
              parent_idx = main_region,
              rgb = how_UI:get_random_rgb()

            }
  )
  ]]

  switch_region = how_UI:add_area(
        {

          --width_pct = 100,
          --height_pct = 12.5,
          min_pct = 10,
          fill = "",
          mode = "line",
          ext_anchor = "",
          int_anchor = "NW",
          parent_idx = full_region,
          rgb = white,
          rx = 5,
          ry = 5,
          segments = 10,
          line_style = "smooth",

          --line_width = 10
          

        }
  )
  
  switch_idx = how_UI:add_area(
        {

          --width_pct = 100,
          --height_pct = 12.5,
          min_pct = 90,
          fill = "",
          mode = "",
          ext_anchor = "",
          int_anchor = "SE",
          parent_idx = switch_region,
          rgb = black,
          
          line_style = "smooth",

          --line_width = 10
          widget = button:new(
          
            {
              --text = "THE FITNESS\n GRAM PASCER \nTEXT IS A \nMUILTI STAGE \nEXAM THTA",
              --text = tostring(i),

              text = "<",
              text_anchor = "C",
              --mode = "line",
              --img = "armilk88-2049037086209040422-01.jpg",
              --img_anchor = "NW",
              --font_style = 35,
              --font_path = "fonts/VT323-Regular.ttf",
              --word_wrap = true
              font_size = 35,
              font_path = font_path_2,
              draw_polygon = true,
              draw_image = true,
              rgb = white,
              rx = 5,
              ry = 5,
              segments = 10,
              line_width = 3

            }

          )

        }
  )

  --[[
    MOVEMENT = {
  IS_TANK        = false,
  IS_TOPDOWN     = false,
  IS_PLATFORMER  = false,
  IS_TILE_BUTTON = false,
  IS_TILE_CLICK  = false,
  IS_CLICK       = true
}
  ]]
  local lorum = "MOVEMENT:"
  lorum = lorum.."\n TANK, TOPDOWN, T-BUTTON: \n\tArrow Keys/WASD"
  lorum = lorum.."\n PLATFORMER: \n\tArrow Keys"
  lorum = lorum.."\n T-CLICK, CLICK: \n\tLeft Mouse Button"
  lorum = lorum.."\n SHOOTING:\n\tRight Mouse Button"

  context_idx = how_UI:add_area(
    {
    
    --fill = "X",
    mode = "fill",
    ext_anchor = "",
    int_anchor = "NW",
    parent_idx = main_region,
    width_pct = 90,
    height_pct = 100,
    rgb = white,
    rx = 5,
    ry = 5,
    segments = 10,
    widget = button:new(
        {
          --text = "This the default text and it sucks how it goes, stupid, stupid, dumb, dumb, fool, fool, and more dumb",
          mode = "line",
          text = lorum,
          text_anchor = "NW",
          text_rgb = black,
          rgb = white,
          --img = "twitter trend-25.png",
          --img_anchor = "NW", 
          font_size = 25,
          font_path = font_path_2,
          word_wrap = true,
          
          name = "text_btn",
          use_scissor = true,
          clip_text = false,
          draw_polygon = true,
          draw_image = true,
          rx = 5,
          ry = 5,
          segments = 10

        }
      )
    }
  )

  context_scl = how_UI:add_area(
    {

    --fill = "X",
    mode = "line",
    ext_anchor = "",
    int_anchor = "NE",
    parent_idx = main_region,
    width_pct = 10,
    height_pct = 100,
    rgb = white,
    rx = 5,
    ry = 5,
    segments = 10,
    widget = scale:new(
        {
          
          rgb = white,
          mode = "fill",

          rx = 5,
          ry = 5,
          segments = 5,

            line_width = 2,
          show_scroll_limit = true,
          progress = 0,
          has_scrollbar = true,
          is_vertical = true,
          is_flipped = false,
          --is_horizontal = true,
          --is_circular = true
          name = "nu_scl"
          

        }
      )
    }
  )

  how_UI:draw()
end

local function hover_widget(dt, start_idx, end_idx)
  end_idx = end_idx or -1


  --[[
            --FLUX TWEEN OPTIONS
                linear 
                quadin quadout quadinout 
                cubicin cubicout cubicinout 
                quartin quartout quartinout 
                quintin quintout quintinout 
                expoin expoout expoinout 
                sinein sineout sineinout 
                circin circout circinout 
                backin backout backinout 
                elasticin elasticout elasticinout
            ]]
  if end_idx == -1 then
    local button = how_UI.widgets[start_idx]
    local og_area = how_UI.areas[start_idx]
    local og_area_w = og_area.x2 - og_area.x1
    local og_area_h = og_area.y2 - og_area.y1
    if button ~= "" then
      if button:_is_hovering_over(mx, my) then

        button.text_rgb = black
        button.rgb = white
        button.mode = "fill"

        


        FLUX.to(
              
                      button.area, 
                      0.5, 
                      {

                        x1 = og_area.x1 - og_area_w * 0.10,
                        y1 = og_area.y1 - og_area_h * 0.10,
                        x2 = og_area.x2 + og_area_w * 0.10,
                        y2 = og_area.y2 + og_area_h * 0.10

                      }
                    
                    )
      else

        button.text_rgb = white
        button.rgb = white
        button.mode = "line"

        FLUX.to(
              
                      button.area, 
                      0.5, 
                      {

                        x1 = og_area.x1,
                        y1 = og_area.y1,
                        x2 = og_area.x2,
                        y2 = og_area.y2

                      }
                    
                    )

      end     

    end


    
  else
      for i = start_idx, end_idx do
        --print(i)
        local button = how_UI.widgets[i]
        if button ~= "" then
          local idx = i - cell_start + 1
          local og_area = how_UI.areas[i]
          local og_area_w = og_area.x2 - og_area.x1
          local og_area_h = og_area.y2 - og_area.y1

          --print(i, button.area.x1, button.area.y1, button.area.x2, button.area.y2, button.area.x1, button.area.y1, button.area.x2, button.area.y2 )
          --local black = {r = 0, g = 0, b = 0, a = 1}
          --local white = {r = 1, g = 1, b = 1, a = 1}
          
          --if i ~= cell_selected then
            if button:_is_hovering_over(mx, my) then

              button.text_rgb = black
              button.rgb = white
              button.mode = "fill"
              
              
              --button.area = og_area
              FLUX.to(
              
                      button.area, 
                      0.5, 
                      {

                        x1 = og_area.x1 - og_area_w * 0.25,
                        y1 = og_area.y1 - og_area_h * 0.25,
                        x2 = og_area.x2 + og_area_w * 0.25,
                        y2 = og_area.y2 + og_area_h * 0.25

                      }
                    
                    )
            
              
            else

              button.text_rgb = white
              button.rgb = white
              button.mode = "line"

              --button.area = og_area
              FLUX.to(
              
                      button.area, 
                      0.5, 
                      {

                        x1 = og_area.x1,
                        y1 = og_area.y1,
                        x2 = og_area.x2,
                        y2 = og_area.y2

                      }
                    
                    )
              
            
            end
          --end
        end
        --print("Cell", i - cell_start + 1)
        
        

      end


      
    end
    FLUX.update(dt)
end



local function draw_widget(use_area, start_idx, end_idx)
  end_idx = end_idx or -1

  if end_idx == -1 then


    local button = how_UI.widgets[start_idx]
    local area = how_UI.areas[start_idx]
    if button ~= "" then
      if use_area then
          button.area = area
      end
      button:draw()
    end


  else 


    for i = start_idx, end_idx do
      local button = how_UI.widgets[i]
      local area = how_UI.areas[i]
      if button ~= "" then
        if use_area then
          button.area = area
        end
        button:draw()
      end
    end


  end
end

function HOW_SCENE:init()
    -- runs only once
    setup_UI()
end

function HOW_SCENE:enter()
    -- runs every time the scene is entered
    setup_UI()
end

function HOW_SCENE:leave()
    -- runs every time the scene is exited
  
end




function HOW_SCENE:update(dt)
    mx, my = love.mouse.getPosition()
    local RMB = love.mouse.isDown(1)

    
    local contxt_btn = how_UI.widgets[context_idx]
    local contxt_scl = how_UI.widgets[context_scl]
    if RMB then
        --print("akskdmalskd")

        contxt_scl:_drag_value(mx, my, dt) 
        --print(widget.progress)
 
        
    end
    contxt_btn.text_pct = contxt_scl:_get_progress()

    hover_widget(dt, switch_idx)
end

function HOW_SCENE:draw()
  
    draw_widget(false, switch_idx)
    draw_widget(true, context_idx)
    draw_widget(true, context_scl)
end

function HOW_SCENE:keyreleased(key, code)

end

function HOW_SCENE:wheelmoved(x, y)
    local contxt_scl = how_UI.widgets[context_scl]

    contxt_scl:_is_wheel_moved(mx, my, -1 * y)
    
end

function HOW_SCENE:mousepressed(x, y, button, istouch)
    local btn_switch = how_UI.widgets[switch_idx]
      local RMB_down = button == 1
  local LMB_down = button == 2

  if RMB_down then
    

    if btn_switch:_is_hovering_over(mx, my) then
      
      GAMESTATE.switch(MENU_SCENE)
    end 
    


  end
end

function HOW_SCENE:resize(w, h)
    how_UI.areas[1] = {x1 = 0, y1 = 0, x2 = SCREEN_WIDTH, y2 = SCREEN_HEIGHT}
    how_UI:update_areas()
    how_UI:draw()
end

